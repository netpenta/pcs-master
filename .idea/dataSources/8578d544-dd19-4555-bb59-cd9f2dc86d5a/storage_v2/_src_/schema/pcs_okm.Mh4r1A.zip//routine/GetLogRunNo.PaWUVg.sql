create
    definer = root@localhost procedure GetLogRunNo(OUT logno varchar(20))
BEGIN
	DECLARE logcnt int default 0;
    DECLARE footstr int default DATE_FORMAT(now(), '%y%m%d');
    SET logno = (SELECT CONCAT(header_string, mns_footer_string, LPAD(mns_serial_no, digits, '0')) FROM (
		SELECT report_cd, @serial_no:=(case when COUNT(mns_serial_no) = 0 then 1 else mns_serial_no + 1 end) as mns_serial_no, case when header_string is null then 'L' else header_string end as header_string, case when count(mns_serial_no) = 0 then footstr else mns_footer_string end as mns_footer_string, case when digits is null then 6 else digits end as digits FROM m_numbers mn
		LEFT OUTER JOIN (SELECT report_cd as mns_report_cd, serial_no as mns_serial_no, footer_string as mns_footer_string FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'LOG' AND header_string = 'L' AND footer_string = footstr) mns on mn.report_cd = mns.mns_report_cd WHERE deleted_flg = 0 AND report_cd = 'LOG' AND header_string = 'L'
    ) logno);
    SELECT IFNULL(COUNT(1), 0) INTO logcnt FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'LOG' AND header_string = 'L';
    IF logcnt = 0 THEN
		INSERT INTO m_numbers (report_cd, serial_no, header_string, footer_string, start_no, end_no, digits, factory_cd, report_nm, yymmdd_digits, deleted_flg, user_id, program_id, created_datetime) 
        VALUES ('LOG', @serial_no, 'L', footstr, 1, 999999, 6, '', 'LOG NO.', 6, 0, 'GetLogRunNo', now());
    ELSE
		UPDATE m_numbers SET serial_no = @serial_no, footer_string = footstr, modified_datetime = now() WHERE report_cd = 'LOG' AND header_string = 'L';
    END IF;
END;

