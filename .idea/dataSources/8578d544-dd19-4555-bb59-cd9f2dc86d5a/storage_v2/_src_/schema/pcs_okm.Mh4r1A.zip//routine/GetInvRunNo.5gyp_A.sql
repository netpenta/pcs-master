create
    definer = root@localhost procedure GetInvRunNo(IN factcd varchar(50), IN invdate int, OUT hdno varchar(50),
                                                   OUT runno int)
BEGIN	
         DECLARE running int default 1;    
         SET running = (SELECT CASE WHEN (SELECT COUNT(1) FROM inv_doc_header WHERE inv_deleted_flg = 0 AND inv_factory_cd = factcd AND inv_issued_date = invdate) = 0 THEN 1 ELSE (SELECT max(invoice_no)+1 as invoice_no FROM inv_doc_header WHERE inv_deleted_flg = 0 AND inv_factory_cd = factcd AND inv_issued_date = invdate) END);    
         SELECT running INTO runno;	
         IF running = 1 THEN SELECT CONCAT(header_string, SUBSTR(invdate, 3)) INTO hdno FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'INVDOC' AND factory_cd = factcd;	
         ELSE SELECT CONCAT(header_string, SUBSTR(invdate, 3)) INTO hdno FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'INVDOC' AND factory_cd = factcd; 	
         END IF;
END;

