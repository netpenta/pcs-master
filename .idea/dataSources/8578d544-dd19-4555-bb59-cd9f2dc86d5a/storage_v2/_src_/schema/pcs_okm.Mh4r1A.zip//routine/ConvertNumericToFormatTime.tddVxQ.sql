create
    definer = root@localhost function ConvertNumericToFormatTime(param_time_numeric decimal(6), param_time_format varchar(10)) returns varchar(20)
BEGIN
   DECLARE time_str VARCHAR(20);   
	SET time_str = IFNULL(TIME_FORMAT(STR_TO_DATE(LPAD(param_time_numeric, 6, 0), '%H%i%s'), param_time_format), '');
	RETURN time_str;
END;

