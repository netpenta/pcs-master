create
    definer = root@localhost function CalculateNgStockQttyByItem(param_this_month_start_date int,
                                                                 param_this_month_end_date int,
                                                                 param_item_cust_cd varchar(50),
                                                                 param_item_cd varchar(250),
                                                                 param_item_rev_no varchar(50),
                                                                 param_proc_cd varchar(50),
                                                                 param_place_cd varchar(50)) returns decimal(13, 3)
BEGIN
   DECLARE first_ng_qtty DECIMAL(13,3);   
	SET first_ng_qtty = IFNULL((
		SELECT   SUM((CASE WHEN inout_div IN (55,22,53,82) THEN inout_qtty ELSE 0 END))
	   FROM st_lot_inout 
	   WHERE inout_date >= param_this_month_start_date AND inout_date <= param_this_month_end_date
	   AND   item_cust_cd = param_item_cust_cd AND item_cd = param_item_cd AND item_rev_no = param_item_rev_no AND proc_cd = param_proc_cd AND place_cd = param_place_cd
      GROUP BY place_cd, proc_cd, item_cust_cd, item_cd, item_rev_no
	), 0.000);
	RETURN first_ng_qtty;
END;

