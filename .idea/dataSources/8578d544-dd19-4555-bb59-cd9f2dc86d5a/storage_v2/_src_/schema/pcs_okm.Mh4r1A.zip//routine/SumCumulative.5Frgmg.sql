create
    definer = root@localhost procedure SumCumulative(IN itemcustcd varchar(50), IN itemcd varchar(50),
                                                     IN itemrevno varchar(20), IN custcd varchar(50),
                                                     IN branchcd varchar(50), IN cumyear decimal(4),
                                                     IN cumstartdate decimal(8), IN cumenddate decimal(8),
                                                     IN invqtty decimal(13, 3), IN userid varchar(50),
                                                     IN pgmid varchar(50), OUT success int)
BEGIN
	DECLARE foundrow int default 0;
    SET success = 0;
    
    SELECT @inv_qtty:=inv_qtty, @cum_qtty:=cum_qtty, @cum_end_date:=cum_end_date FROM inv_cum WHERE item_cust_cd = itemcustcd AND item_cd = itemcd AND item_rev_no = itemrevno AND cust_cd = custcd AND branch_cd = branchcd AND cum_year = cumyear;
    SELECT FOUND_ROWS() INTO foundrow;
    IF foundrow > 0 THEN
		UPDATE inv_cum SET
        inv_qtty				= @inv_qtty + invqtty, 
        cum_qtty				= @cum_qtty + invqtty, 
        cum_end_date			= IF(cumenddate > @cum_end_date, cumenddate, @cum_end_date), 
        cum_modified_user_id	= userid, 
        cum_program_id			= pgmid, 
        cum_modified_datetime	= now() 
		WHERE item_cust_cd		= itemcustcd 
        AND item_cd				= itemcd 
        AND item_rev_no			= itemrevno 
        AND cust_cd				= custcd 
        AND branch_cd			= branchcd 
        AND cum_year			= cumyear;
        SELECT ROW_COUNT() INTO success;
    ELSE
		INSERT inv_cum SET	
        item_cust_cd			= itemcustcd, 
        item_cd					= itemcd, 
        item_rev_no				= itemrevno, 
        cust_cd					= custcd, 
        branch_cd				= branchcd, 
        cum_year				= cumyear, 
        cum_start_date			= cumstartdate, 
        cum_end_date			= cumenddate, 
        inv_qtty				= invqtty, 
        cum_qtty				= invqtty, 
        cum_created_user_id		= userid, 
        cum_created_datetime	= now();
        SELECT ROW_COUNT() INTO success;
    END IF;
END;

