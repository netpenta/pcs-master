create
    definer = root@localhost procedure GetPlanSummary(IN in_stock_yyyymm int, IN in_dodate_from int,
                                                      IN in_dodate_to int, IN in_dodate_7 int,
                                                      IN in_item_cust_cd varchar(50), IN in_item_cd varchar(50),
                                                      IN in_item_revno varchar(50), IN in_machineset_cd varchar(50),
                                                      IN in_workplace_cd varchar(50), IN in_movement_flg int,
                                                      IN in_pagerow int, IN in_pagesize int)
BEGIN

SELECT  plan.parent_item_cd, plan.summ_index, plan.summ_type, plan.item_cust_cd, plan.item_cd, plan.item_rev_no, plan.proc_cd, plan.work_place_cd, plan.stock_place_cd, place.std_work_time, place.std_wait_time, place.std_preparation_time,

        IF(plan.summ_index = 1, (SELECT GetStockQttyByItem(in_stock_yyyymm, in_dodate_from, in_dodate_from, plan.item_cust_cd, plan.item_cd, plan.item_rev_no, plan.proc_cd, plan.stock_place_cd)), '') as summ_stock_qtty,

        IFNULL(IF(plan.summ_index = 1, prod_prev_qtty , IF(plan.summ_index = 2, used_prev_qtty , IF(plan.summ_index = 3, ship_prev_qtty , 0))), 0) as summ_prev_qtty,

        IFNULL(IF(plan.summ_index = 1, prod_total_qtty, IF(plan.summ_index = 2, used_total_qtty, IF(plan.summ_index = 3, ship_total_qtty, 0))), 0) as summ_total_qtty,

        IFNULL(IF(plan.summ_index = 1, prod_next_qtty , IF(plan.summ_index = 2, used_next_qtty , IF(plan.summ_index = 3, ship_next_qtty , 0))), 0) as summ_next_qtty,

        IFNULL(IF(plan.summ_index = 1, prod_summ_date , IF(plan.summ_index = 2, used_summ_date , IF(plan.summ_index = 3, ship_summ_date , 0))), 0) as summ_data_date,

        IFNULL(IF(plan.summ_index = 1, prod_summ_qtty , IF(plan.summ_index = 2, used_summ_qtty , IF(plan.summ_index = 3, ship_summ_qtty , 0))), 0) as summ_data_qtty,

        IFNULL(IF(plan.summ_index = 1, prod_summ_data , IF(plan.summ_index = 2, used_summ_data , IF(plan.summ_index = 3, ship_summ_data , 0))), 0) as summ_data

FROM(

	  SELECT DISTINCT plan.parent_item_cd, summ_index, plan.level, summ_type, plan.item_cust_cd, plan.item_cd, plan.item_rev_no, proc.proc_cd, plan.work_place_cd, plan.stock_place_cd, plan.machine_set_cd

	  FROM pl_sched_detail as plan

     CROSS JOIN(SELECT 1 as summ_index, 'PROD' as summ_type UNION SELECT 2 as summ_index, 'USE' as summ_type UNION SELECT 3 as summ_index, 'SHIP' as summ_type ) as typeofdata     

     LEFT OUTER JOIN m_item_procs  as proc  ON proc.item_cust_cd  = plan.item_cust_cd  AND proc.item_cd = plan.item_cd AND proc.item_rev_no = plan.item_rev_no AND proc.line_no = plan.item_proc_line_no     

     LEFT OUTER JOIN m_item_places as place ON place.item_cust_cd = plan.item_cust_cd  AND place.item_cd= plan.item_cd AND place.item_rev_no= plan.item_rev_no AND place.work_place_cd= plan.work_place_cd AND place.item_proc_line_no = plan.item_proc_line_no AND place.sort_no = 1

     WHERE  plan.plan_prod_date >= in_dodate_from AND plan.plan_prod_date <= in_dodate_to AND proc.proc_div <> 4 AND plan.finished_flg = 0 
     
     AND    plan.expand_div IN (0,2) AND plan.item_rev_no NOT LIKE '%_MOVE%'

	  

	  AND    plan.item_cust_cd = CASE WHEN LENGTH(in_item_cust_cd) > 0 THEN in_item_cust_cd ELSE plan.item_cust_cd END    

	  AND    plan.item_cd = CASE WHEN LENGTH(in_item_cd) > 0 THEN in_item_cd ELSE plan.item_cd END    

     AND    plan.machine_set_cd = CASE WHEN LENGTH(in_machineset_cd) > 0 THEN in_machineset_cd ELSE plan.machine_set_cd END

     AND    plan.work_place_cd = CASE WHEN LENGTH(in_workplace_cd) > 0 THEN in_workplace_cd ELSE plan.work_place_cd END   

	  ORDER BY plan.item_cd, summ_index LIMIT in_pagerow, in_pagesize

)as plan 

LEFT OUTER JOIN m_item_places as place ON place.item_cust_cd = plan.item_cust_cd AND place.item_cd= plan.item_cd AND place.item_rev_no= plan.item_rev_no AND place.work_place_cd = plan.work_place_cd AND place.machine_set_cd = plan.machine_set_cd     

JOIN (SELECT @balance_qtty:=0) AS define_variable

LEFT JOIN (

	  SELECT 1 as summ_index, item_cust_cd, item_cd, item_rev_no, SUM(prod_prev_qtty) as prod_prev_qtty, SUM(request_remain) as prod_total_qtty, SUM(prod_next_qtty) as prod_next_qtty,

            GROUP_CONCAT(IF(plan_prod_date >= in_dodate_from AND plan_prod_date <= in_dodate_to, plan_prod_date , null) ORDER BY plan_prod_date) as prod_summ_date,

            GROUP_CONCAT(IF(plan_prod_date >= in_dodate_from AND plan_prod_date <= in_dodate_to, request_remain , null) ORDER BY plan_prod_date) as prod_summ_qtty,

            GROUP_CONCAT(IF(plan_prod_date >= in_dodate_from AND plan_prod_date <= in_dodate_to, CONCAT(request_remain,'/',request_qtty_struct_unit) , null) ORDER BY plan_prod_date) as prod_summ_data

     FROM(

			SELECT   detail.plan_prod_date, detail.item_cust_cd, detail.item_cd, detail.item_rev_no,

					 IF(detail.plan_prod_date <  in_dodate_from, SUM(detail.request_remain_struct_unit), 0) as prod_prev_qtty,

					 IF(detail.plan_prod_date >= in_dodate_from AND detail.plan_prod_date <= in_dodate_to, SUM(detail.request_remain_struct_unit), 0) as request_remain,

					 IF(detail.plan_prod_date >= in_dodate_from AND detail.plan_prod_date <= in_dodate_to, SUM(detail.request_qtty_struct_unit)  , 0) as request_qtty_struct_unit,

					 IF(detail.plan_prod_date >  in_dodate_to  , SUM(detail.request_remain_struct_unit), 0) as prod_next_qtty

			FROM     pl_sched_detail as detail

         WHERE    detail.finished_flg = 0 AND plan_prod_date >= (SELECT this_month_start_date FROM m_sys_admin) AND plan_prod_date <= in_dodate_7 
         
         AND      detail.expand_div IN (0,2) AND detail.item_rev_no NOT LIKE '%_MOVE%'

	      AND      detail.item_cust_cd LIKE CASE WHEN LENGTH(in_item_cust_cd) > 0 THEN in_item_cust_cd ELSE '%%' END

         AND      detail.item_cd LIKE CASE WHEN LENGTH(in_item_cd) > 0 THEN in_item_cd ELSE '%%' END

         AND      detail.machine_set_cd LIKE CASE WHEN LENGTH(in_machineset_cd) > 0 THEN in_machineset_cd ELSE '%%' END

         AND      detail.work_place_cd LIKE CASE WHEN LENGTH(in_workplace_cd) > 0 THEN in_workplace_cd ELSE '%%' END           

         GROUP BY detail.plan_prod_date, detail.item_cust_cd, detail.item_cd, detail.item_rev_no

     )as plandetail GROUP BY item_cust_cd, item_cd, item_rev_no

)as prod ON prod.summ_index = plan.summ_index AND prod.item_cust_cd = plan.item_cust_cd AND prod.item_cd = plan.item_cd AND prod.item_rev_no = plan.item_rev_no

LEFT JOIN (

	  SELECT 2 as summ_index, item_cust_cd, item_cd, item_rev_no, SUM(used_prev_qtty) as used_prev_qtty, SUM(request_remain) as used_total_qtty, SUM(used_next_qtty) as used_next_qtty,

            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, plan_delivery_date, null) ORDER BY plan_delivery_date) as used_summ_date,

            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, request_remain , null) ORDER BY plan_delivery_date) as used_summ_qtty,

            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, CONCAT(request_remain,'/',request_qtty_struct_unit) , null) ORDER BY plan_delivery_date) as used_summ_data

     FROM(

			SELECT     detail.plan_delivery_date, detail.item_cust_cd, detail.item_cd, detail.item_rev_no,

					  IF(detail.plan_delivery_date  < in_dodate_from, SUM(detail.request_remain_struct_unit), 0) as used_prev_qtty,

					  IF(detail.plan_delivery_date >= in_dodate_from AND detail.plan_delivery_date <= in_dodate_to, SUM(detail.request_remain_struct_unit), 0) as request_remain,

					  IF(detail.plan_delivery_date >= in_dodate_from AND detail.plan_delivery_date <= in_dodate_to, SUM(detail.request_qtty_struct_unit), 0)   as request_qtty_struct_unit,

					  IF(detail.plan_delivery_date > in_dodate_to  , SUM(detail.request_remain_struct_unit), 0) as used_next_qtty

			FROM      pl_sched_detail as detail		

         WHERE     detail.finished_flg = 0 AND detail.plan_delivery_date >= (SELECT this_month_start_date FROM m_sys_admin) AND detail.plan_delivery_date <= in_dodate_7 
         
         AND       detail.expand_div IN (1,9) AND detail.item_rev_no NOT LIKE '%_MOVE%'

	      AND       detail.item_cust_cd = CASE WHEN LENGTH(in_item_cust_cd) > 0 THEN in_item_cust_cd ELSE detail.item_cust_cd END

         AND       detail.item_cd = (CASE WHEN LENGTH(in_item_cd) > 0 THEN in_item_cd ELSE detail.item_cd END)

         AND       detail.machine_set_cd = CASE WHEN LENGTH(in_machineset_cd) > 0 THEN in_machineset_cd ELSE detail.machine_set_cd END

         AND       detail.work_place_cd = CASE WHEN LENGTH(in_workplace_cd) > 0 THEN in_workplace_cd ELSE detail.work_place_cd END

         GROUP BY  detail.plan_delivery_date, detail.item_cust_cd, detail.item_cd, detail.item_rev_no

     )as plandetail GROUP BY item_cust_cd, item_cd, item_rev_no

)as used ON used.summ_index = plan.summ_index AND used.item_cust_cd = plan.item_cust_cd AND used.item_cd = plan.item_cd AND used.item_rev_no = plan.item_rev_no

LEFT JOIN (

	  SELECT 3 as summ_index, item_cust_cd, item_cd, item_rev_no, SUM(ship_prev_qtty) as ship_prev_qtty, SUM(s_order_remain) as ship_total_qtty, SUM(ship_next_qtty) as ship_next_qtty,

            GROUP_CONCAT(IF(delivery_date >= in_dodate_from AND delivery_date <= in_dodate_to, delivery_date, null) ORDER BY delivery_date) as ship_summ_date,

            GROUP_CONCAT(IF(delivery_date >= in_dodate_from AND delivery_date <= in_dodate_to, s_order_remain , null) ORDER BY delivery_date) as ship_summ_qtty,

            GROUP_CONCAT(IF(delivery_date >= in_dodate_from AND delivery_date <= in_dodate_to, CONCAT(s_order_remain,'/',s_order_qtty_s_order_unit) , null) ORDER BY delivery_date) as ship_summ_data

     FROM(

			SELECT     ro.delivery_date, ro.item_cust_cd, ro.item_cd, ro.item_rev_no,

					  IF(ro.delivery_date <  in_dodate_from, SUM(ro.s_order_remain_s_order_unit), 0) as ship_prev_qtty,

					  IF(ro.delivery_date >= in_dodate_from AND ro.delivery_date <= in_dodate_to, SUM(ro.s_order_remain_s_order_unit), 0) as s_order_remain,

					  IF(ro.delivery_date >= in_dodate_from AND ro.delivery_date <= in_dodate_to, SUM(ro.s_order_qtty_s_order_unit)  , 0) as s_order_qtty_s_order_unit,

					  IF(ro.delivery_date > in_dodate_to  , SUM(ro.s_order_remain_s_order_unit), 0) as ship_next_qtty

			FROM      ro_data as ro

         WHERE     ro.finished_flg = 0 AND ro.delivery_date >= (SELECT this_month_start_date FROM m_sys_admin) AND ro.delivery_date <= in_dodate_7 

	      AND       ro.item_cust_cd LIKE CASE WHEN LENGTH(in_item_cust_cd) > 0 THEN in_item_cust_cd ELSE '%%' END

         AND       ro.item_cd LIKE CASE WHEN LENGTH(in_item_cd) > 0 THEN in_item_cd ELSE '%%' END 

         AND       ro.subcontract_flg = 0

         GROUP BY  ro.delivery_date, ro.item_cust_cd, ro.item_cd, ro.item_rev_no

     )as ro GROUP BY item_cust_cd, item_cd, item_rev_no

)as ship ON ship.summ_index = plan.summ_index AND ship.item_cust_cd = plan.item_cust_cd AND ship.item_cd = plan.item_cd AND ship.item_rev_no = plan.item_rev_no

ORDER BY plan.item_cd ASC, plan.summ_index;

END;

