create
    definer = root@localhost procedure UpdateOrderRunNo(IN rono varchar(20), IN running decimal(12))
BEGIN       
	DECLARE rocnt int default 0;       
	DECLARE footstr varchar(10) default SUBSTR(REPLACE(rono, 'RO', ''), 1, 4);           
    SELECT IFNULL(COUNT(1), 0) INTO rocnt FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'RO';       
    IF rocnt = 0 THEN           
		INSERT INTO m_numbers (report_cd, serial_no, header_string, footer_string, start_no, end_no, digits, factory_cd, report_nm, yymmdd_digits, deleted_flg, user_id, program_id, created_datetime)           VALUES ('RO', running, 'RO', footstr, 1, 999999, 6, '', 'RECEIVING ORDER', 4, 0, 'UpdateOrderRunNo', now());       
	ELSE           
		UPDATE m_numbers SET serial_no = running, footer_string = footstr, modified_datetime = now() WHERE deleted_flg = 0 AND report_cd = 'RO';       
	END IF; 
END;

