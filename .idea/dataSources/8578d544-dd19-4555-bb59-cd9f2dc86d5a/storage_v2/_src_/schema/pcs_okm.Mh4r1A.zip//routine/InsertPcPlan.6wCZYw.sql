create
    definer = root@localhost procedure InsertPcPlan(IN factcd varchar(20), IN orderno varchar(50), IN orderbrno int,
                                                    IN supplier varchar(50), IN dlvydt int, IN itemcd varchar(50),
                                                    IN itemcustcd varchar(50), IN itemrevno varchar(20),
                                                    IN itemnm varchar(300), IN stplace varchar(50),
                                                    IN proccd varchar(20), IN procdiv int, IN orderleadtm int,
                                                    IN minorderqty int, IN orderrate decimal(13, 3),
                                                    IN orderup decimal(13, 3), IN noupflg int, IN snp decimal(13, 3),
                                                    IN ordertyp int, IN orderqty decimal(13, 3),
                                                    IN resultqty decimal(13, 3), IN sorderno varchar(20),
                                                    IN usrid varchar(50), IN pgmcd varchar(50),
                                                    IN pgmidversion varchar(100), OUT success int,
                                                    OUT logerr varchar(500), IN filenm varchar(500),
                                                    IN prodno varchar(50))
BEGIN
	DECLARE pcno varchar(20);
    DECLARE running int default 1;
    DECLARE logno varchar(20);
    DECLARE pgmnm varchar(100) default 'Purchase Plan';
    DECLARE planstdt int default 0;
    DECLARE holiflg int default 0;
    DECLARE foundrow int default 0;
    DECLARE vatdiv int default 0;
    SET success = 0;
    SELECT holiday_flg INTO holiflg FROM m_wkgp_calendars WHERE deleted_flg = 0 AND work_place_cd = stplace AND cal_date = dlvydt LIMIT 1;
    SELECT FOUND_ROWS() INTO foundrow;
    IF foundrow = 0 THEN
		
		SET logerr = CONCAT('[Work Calendar Master] Cannot find work calendar in ', DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m%d'), '%d/%m/%Y'), ' period.');
		CALL InsertLog(logno, 'I', pgmcd, pgmnm, 'Work Calendar Master', logerr, usrid, pgmidversion);
    ELSE
		IF holiflg = 9 and ordertyp = 3 THEN
			
			SET logerr = CONCAT('[Work Calendar Master] ', DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m%d'), '%d/%m/%Y'), ' stock store : ', stplace ,' is holiday.');
			CALL InsertLog(logno, 'I', pgmcd, pgmnm, 'Work Calendar Master', logerr, usrid, pgmidversion);
        ELSE
			SELECT MAX(cal_date) as cal_date INTO planstdt FROM m_wkgp_calendars WHERE deleted_flg = 0 AND holiday_flg != 9 AND work_place_cd = stplace AND cal_date <= DATE_FORMAT(DATE(DATE_ADD(dlvydt, INTERVAL orderleadtm DAY)), '%Y%m%d');
			SELECT FOUND_ROWS() INTO foundrow;
            IF foundrow = 0 THEN
				SET planstdt = DATE_FORMAT(now(), '%Y%m%d');
			ELSE 
                IF planstdt < DATE_FORMAT(now(), '%Y%m%d') THEN
					SET planstdt = DATE_FORMAT(now(), '%Y%m%d');
                END IF;
            END IF;        
				    
            IF orderno != '' THEN
            
				UPDATE pur_data SET 
                payment_supplier_cd							= (SELECT payment_place_cd FROM m_places WHERE deleted_flg = 0 AND place_cd = supplier AND effect_date <= DATE_FORMAT(now(), '%Y%m%d') AND exp_date >= DATE_FORMAT(now(), '%Y%m%d') LIMIT 1), 
				item_proc_line_no							= (SELECT line_no FROM m_item_procs WHERE deleted_flg = 0 AND item_cust_cd = itemcustcd AND item_cd = itemcd AND item_rev_no = itemrevno AND proc_div = procdiv LIMIT 1), 
                plan_start_date								= planstdt, 
                plan_delivery_date							= dlvydt, 
                delivery_place								= stplace, 
                request_qtty								= IF(IFNULL(orderrate,0)=0, orderqty, (orderqty / orderrate)), 
                p_order_unit_price							= orderup, 
                vat_div										= (SELECT vat_div FROM m_places WHERE deleted_flg = 0 AND outside_flg = 1 AND place_cd = supplier AND effect_date <= DATE_FORMAT(now(), '%Y%m%d') AND exp_date >= DATE_FORMAT(now(), '%Y%m%d')),
                p_order_price								= 0, 
                p_order_price_exclude_vat					= 0, 
                vat_amt										= 0, 
                no_unit_price_flg							= noupflg, 
                request_remain								= (IF(IFNULL(orderrate,0)=0, orderqty, (orderqty / orderrate)) - (resultqty / orderrate)), 
                fixed_div									= ordertyp, 
                spot_flg									= 0, 
                start_date									= planstdt, 
                delivery_date								= dlvydt, 
                necessary_qtty								= IF(IFNULL(orderrate,0)=0, orderqty, (orderqty / orderrate)), 
                proc_cd										= proccd, 
                snp											= snp, 
                request_qtty_p_order_unit					= orderqty, 
                request_remain_p_order_unit					= (orderqty - resultqty), 
                file_name									= filenm,
                user_id										= usrid,
                program_id									= pgmidversion, 
                modified_datetime							= now() 

                WHERE p_order_no							= orderno 
                AND p_order_br_no							= orderbrno 
                AND factory_cd_from							= factcd 
                AND supplier_cd								= supplier
                AND item_cust_cd							= itemcustcd 
                AND item_cd									= itemcd 
                AND item_rev_no								= itemrevno;
				SELECT ROW_COUNT() INTO success;
			ELSE
				CALL GetPcRunNo(pcno);
				IF pcno = '' OR pcno IS NULL THEN
					
					SET logerr = '[Purchase Plan] Cannot create Plan No.';
					CALL InsertLog(logno, 'E', pgmcd, pgmnm, 'Purchase Plan', logerr, usrid, pgmidversion);
				ELSE
					
					INSERT pur_data SET
					p_order_no								= pcno, 
					p_order_br_no							= 1, 
					prod_no									= prodno, 
					prod_sub_no								= 1, 
					prod_sub_br_no							= 1, 
					division_cd								= (SELECT division_cd FROM m_factory WHERE deleted_flg = 0 AND fact_cd = factcd), 
					factory_cd_from							= factcd, 
					proc_div								= procdiv, 
					factory_cd_to							= factcd, 
					supplier_cd								= supplier, 
					payment_supplier_cd						= (SELECT payment_place_cd FROM m_places WHERE deleted_flg = 0 AND place_cd = supplier AND effect_date <= DATE_FORMAT(now(), '%Y%m%d') AND exp_date >= DATE_FORMAT(now(), '%Y%m%d') LIMIT 1), 
					item_proc_line_no						= (SELECT line_no FROM m_item_procs WHERE deleted_flg = 0 AND item_cust_cd = itemcustcd AND item_cd = itemcd AND item_rev_no = itemrevno AND proc_div = procdiv LIMIT 1), 
					item_cust_cd							= itemcustcd, 
					item_cd									= itemcd, 
					item_rev_no								= itemrevno, 
					plan_yyyymm								= DATE_FORMAT(now(), '%Y%m'), 
					order_date								= DATE_FORMAT(now(), '%Y%m%d'), 
					plan_start_date							= planstdt, 
                    plan_delivery_date						= dlvydt, 
                    delivery_place							= stplace, 
                    plan_qtty								= IF(IFNULL(orderrate,0)=0, orderqty, (orderqty / orderrate)), 
                    request_qtty							= IF(IFNULL(orderrate,0)=0, orderqty, (orderqty / orderrate)), 
                    p_order_unit_price						= orderup, 
                    vat_div									= vatdiv, 
                    p_order_price							= 0, 
                    p_order_price_exclude_vat				= 0, 
                    vat_amt									= 0, 
                    no_unit_price_flg						= noupflg, 
                    result_amt_qtty							= 0, 
                    request_remain							= IF(IFNULL(orderrate,0)=0, orderqty, (orderqty / orderrate)), 
                    fixed_div								= ordertyp, 
                    spot_flg								= 0, 
                    pr_print_flg							= 0, 
                    pr_no									= '', 
                    po_print_flg							= 0, 
                    po_no									= '', 
                    start_date								= planstdt, 
                    delivery_date							= dlvydt, 
                    necessary_qtty							= IF(IFNULL(orderrate,0)=0, orderqty, (orderqty / orderrate)), 
					level									= 0, 
					last_proc_flg							= 0, 
					item_last_proc_flg						= 1, 
					expand_div								= 0, 
					planed_item_cust_cd						= '', 
					planed_item_cd							= '', 
					planed_item_rev_no						= 0,
					parent_item_cust_cd						= '', 
					parent_item_cd							= '', 
					parent_item_rev_no						= 0, 
                    parent_delivery_date					= 0, 
                    parent_prod_plan_qtty					= 0, 
                    parent_item_proc_line_no				= 0, 
                    proc_cd									= proccd, 
                    snp										= snp, 
                    req_qtty								= 0, 
                    s_order_no								= sorderno, 
                    s_order_br_no							= 0, 
                    shift_div								= 0, 
                    plan_qtty_p_order_unit					= orderqty, 
                    request_qtty_p_order_unit				= orderqty, 
                    result_amt_qtty_p_order_unit			= 0, 
                    request_remain_p_order_unit				= orderqty, 
                    finished_flg							= 0, 
                	file_name									= filenm,
                    user_id									= usrid, 
                    program_id								= pgmidversion, 
                    memo_of_numbers							= sorderno,
                    created_datetime						= now();
					SELECT ROW_COUNT() INTO success;
				END IF;
			END IF;
        END IF;
    END IF;
END;

