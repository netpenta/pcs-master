create
    definer = root@localhost procedure InsertRoContForecast_debug(IN partno varchar(50), IN partname varchar(300),
                                                                  IN model varchar(20), IN custcd varchar(50),
                                                                  IN dlvylc varchar(50), IN dlvydt decimal(8),
                                                                  IN dlvytm decimal(6), IN shpdt decimal(8),
                                                                  IN shptm decimal(6), IN orderno varchar(50),
                                                                  IN pdsno varchar(50), IN dlvyno varchar(50),
                                                                  IN orderqty decimal(13, 3),
                                                                  IN forecast decimal(13, 3), IN truckno varchar(50),
                                                                  IN orderdiv decimal(3), IN slipdiv decimal(3),
                                                                  IN shiftdiv decimal(3), IN issdt decimal(8),
                                                                  IN rmk1 varchar(50), IN rmk2 varchar(50),
                                                                  IN rmk3 varchar(50), IN rmk4 varchar(50),
                                                                  IN rmk5 varchar(50), IN rmk6 varchar(50),
                                                                  IN rmk7 varchar(50), IN rmk8 varchar(50),
                                                                  IN rmk9 varchar(50), IN rmk10 varchar(50),
                                                                  IN rmk11 varchar(50), IN rmk12 varchar(50),
                                                                  IN filenm varchar(300), IN shptyp decimal(3),
                                                                  IN ponocnt int, IN caltyp varchar(20),
                                                                  IN usrnm varchar(50), IN pgmid varchar(50),
                                                                  IN pgmidversion varchar(100), OUT success int,
                                                                  INOUT currentNo varchar(20), IN dlvylo2 varchar(50))
BEGIN
	DECLARE foundrow int default 0;
    DECLARE checkrow int default 0;
    DECLARE rono varchar(20);
    DECLARE running int default 1;
    DECLARE robrno int default 1;
    DECLARE shpqtty double;
    DECLARE oridlvydt int;
    DECLARE oridlvytm int;
    DECLARE orisqtty double;
    DECLARE smodel varchar(50);
    DECLARE logno varchar(20);
    DECLARE logerr varchar(500);
    DECLARE pgmnm varchar(100) default 'Receiving Order';
    DECLARE caldt, calno, vat, calcnt INT; 
    DECLARE done INT DEFAULT FALSE;
    DECLARE qtyfst, qty double;
    DECLARE clpln int default 0;
    SET success = 0;
    
    IF forecast = 0 AND orderqty = 0 THEN
		
		SET logerr = CONCAT('[From File] Part No. ', partno, ' (Order No. ', orderno,') has a sales order with 0 order quantity for customer ', custcd, ' - ', dlvylc, ' at this ', DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m/%Y'), ' period.');
		CALL InsertLog(logno, 'I', pgmid, pgmnm, 'From File', logerr, usrnm, pgmidversion);
	ELSE
		SELECT @cust_cd:=msp.cust_cd, @branch_cd:=msp.branch_cd, @cust_serial_no:=mc.cust_serial_no, msp.cust_item_cd, @sales_item_prices_serial_no:=msp.serial_no, @item_cust_cd:=msp.item_cust_cd, @item_cd:=msp.item_cd, @item_rev_no:=msp.item_rev_no, 
		@boi_div:=msp.boi_div, @sales_unit_price:=msp.sales_unit_price, @vat_cd:=msp.vat_cd, @vat_div:=msp.vat_div, @vat_included_in_unit_price:=msp.vat_included_in_unit_price, @billing_cust_cd:=mc.billing_cust_cd, @billing_branch_cd:=mc.billing_branch_cd, @billing_cust_serial_no:=mc.billing_cust_serial_no, @round_div:=mc.round_div, @delivery_lead_time:=mc.delivery_lead_time, @sales_person_cd:=mc.employee_cd, 
		@mi_item_cd:=mi.item_cd, @mi_item_rev_no:=mi.item_rev_no, @item_nm1:=mi.item_nm1, @shipment_place_cd:=mi.shipment_place_cd,
		@model_cd_s_order:= IF(model = '', IF(Mid(dlvylc, 1, 2) = 'KD', IF(msp.model_cd = '', mi.model_nm, msp.model_cd), mi.model_nm), model), 
		@s_order_rate:=mi.s_order_rate, @std_unit_cost:=mi.std_unit_cost, @pur_div:=mip.proc_div, @division_cd:=mp.division_cd, @factory_cd:=mp.factory_cd 
		FROM m_sales_prices msp
		LEFT OUTER JOIN (
			SELECT cust_cd as mc_cust_cd, branch_cd as mc_branch_cd, serial_no as cust_serial_no, billing_cust_cd, billing_branch_cd, delivery_lead_time, employee_cd, billing_cust_serial_no, mcb_round_div as round_div FROM m_customers mc
			LEFT OUTER JOIN (
				SELECT cust_cd as mcb_cust_cd, branch_cd as mcb_branch_cd, serial_no as billing_cust_serial_no, round_div as mcb_round_div FROM m_customers WHERE deleted_flg = 0 AND IFNULL(DATE_FORMAT(STR_TO_DATE(effect_date, '%Y%m%d'), '%Y%m%'), 0) <= dlvydt AND IFNULL(DATE_FORMAT(STR_TO_DATE(exp_date, '%Y%m%d'), '%Y%m%'), 999999) >= dlvydt
			) mcb ON mc.billing_cust_cd = mcb.mcb_cust_cd AND mc.billing_branch_cd = mcb.mcb_branch_cd 
			WHERE deleted_flg = 0 AND IFNULL(DATE_FORMAT(STR_TO_DATE(effect_date, '%Y%m%d'), '%Y%m%'), 0) <= dlvydt AND IFNULL(DATE_FORMAT(STR_TO_DATE(exp_date, '%Y%m%d'), '%Y%m%'), 999999) >= dlvydt
		) mc ON msp.cust_cd = mc.mc_cust_cd AND msp.branch_cd = mc.mc_branch_cd
		LEFT OUTER JOIN m_items as mi ON mi.deleted_flg = 0 AND msp.item_cust_cd = mi.item_cust_cd AND msp.item_cd = mi.item_cd AND msp.item_rev_no = mi.item_rev_no 
		LEFT OUTER JOIN m_item_procs as mip ON mip.sort_no = 1 AND mip.deleted_flg = 0 AND msp.item_cust_cd = mip.item_cust_cd AND msp.item_cd = mip.item_cd AND msp.item_rev_no AND mip.item_rev_no
		LEFT OUTER JOIN m_places as mp ON mp.deleted_flg = 0 AND mi.shipment_place_cd = mp.place_cd 
		WHERE msp.deleted_flg = 0 AND msp.used_flg = 1 AND IFNULL(DATE_FORMAT(STR_TO_DATE(msp.effect_date, '%Y%m%d'), '%Y%m%'), 0) <= dlvydt AND IFNULL(DATE_FORMAT(STR_TO_DATE(msp.exp_date, '%Y%m%d'), '%Y%m%'), 999999) >= dlvydt AND msp.cust_cd = custcd AND msp.branch_cd = dlvylc AND msp.cust_item_cd = partno;
		SELECT FOUND_ROWS() INTO foundrow;
		IF foundrow = 0 THEN
			
			SET logerr = CONCAT('[Sale Price Master] Cannot find price detail in ', partno, ' for customer ', custcd, ' - ', dlvylc, ' at this ', DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m%d'), '%m/%Y'), ' period.');
			CALL InsertLog(logno, 'I', pgmid, pgmnm, 'Sale Price Master', logerr, usrnm, pgmidversion);
		ELSE
			SELECT COUNT(1) INTO foundrow FROM m_wkgp_calendars WHERE deleted_flg = 0 AND cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m');
            IF foundrow = 0 THEN
				SET logerr = CONCAT('[Work Calendar Master] ', DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m%d'), '%m/%Y'), ' not found in calendar.');
				CALL InsertLog(logno, 'I', pgmid, pgmnm, 'Work Calendar Master', logerr, usrnm, pgmidversion);
            ELSE
				SET @rownum = 0;
				CASE caltyp
					WHEN 'first' THEN 
						BEGIN
							DECLARE wkgpcal CURSOR FOR SELECT MIN(mwc.cal_date) as cal_date, @rownum:=@rownum+1 as rownum, mv.vat_percent FROM m_wkgp_calendars mwc 
								LEFT OUTER JOIN m_vat as mv ON mv.deleted_flg = 0 AND mv.vat_effdate <= mwc.cal_date AND mv.vat_expdate >= mwc.cal_date 
								WHERE mwc.holiday_flg = 0 AND mwc.deleted_flg = 0 AND mwc.work_place_cd = @shipment_place_cd AND mwc.cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND mwc.cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m');
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
							SET calcnt = (SELECT COUNT(*) FROM (SELECT MIN(cal_date) as cal_date FROM m_wkgp_calendars WHERE holiday_flg = 0 AND deleted_flg = 0 AND work_place_cd = @shipment_place_cd AND cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m')) calcnt);
							SET qtyfst = (FLOOR(orderqty / calcnt) + (orderqty - (FLOOR(orderqty / calcnt) * calcnt)));
							SET qty    = (FLOOR(orderqty / calcnt));
							OPEN wkgpcal;
								read_loop: LOOP
									FETCH wkgpcal INTO caldt, calno, vat;
									IF done THEN
										LEAVE read_loop;
									END IF;
									
									SET logerr = CONCAT('[caltyp = first] ', 'caldt=', caldt, ', calno=', calno, ', partno=', partno, ', po=', orderno);
									CALL InsertLog(logno, 'I-PGM', pgmid, pgmnm, pgmnm, logerr, usrnm, pgmidversion);



									CALL InsertRoCont_debug(partno, partname, model, custcd, dlvylc, caldt, dlvytm, shpdt, shptm, orderno, pdsno, dlvyno, IF(calno=1, qtyfst, qty), orderqty, truckno, orderdiv, slipdiv, shiftdiv, issdt, 
									rmk1, rmk2, rmk3, rmk4, rmk5, rmk6, rmk7, rmk8, rmk9, rmk10, rmk11, rmk12, filenm, shptyp, ponocnt, caltyp, usrnm, pgmid, pgmidversion, success, rono, clpln, currentNo, dlvylo2);
									
								END LOOP;
							CLOSE wkgpcal;
						END;
					WHEN 'mid' THEN
						BEGIN
							DECLARE wkgpcal CURSOR FOR SELECT MAX(mwc.cal_date) as cal_date, @rownum:=@rownum+1 as rownum, mv.vat_percent FROM m_wkgp_calendars mwc 
								LEFT OUTER JOIN m_vat as mv ON mv.deleted_flg = 0 AND mv.vat_effdate <= mwc.cal_date AND mv.vat_expdate >= mwc.cal_date 
								WHERE mwc.holiday_flg = 0 AND mwc.deleted_flg = 0 AND mwc.work_place_cd = @shipment_place_cd AND mwc.cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND mwc.cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND mwc.cal_day <= 15;
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
							SET calcnt = (SELECT COUNT(*) FROM (SELECT MAX(cal_date) as cal_date FROM m_wkgp_calendars WHERE holiday_flg = 0 AND deleted_flg = 0 AND work_place_cd = @shipment_place_cd AND cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND cal_day <= 15) calcnt);
							SET qtyfst = (FLOOR(orderqty / calcnt) + (orderqty - (FLOOR(orderqty / calcnt) * calcnt)));
							SET qty    = (FLOOR(orderqty / calcnt));
							OPEN wkgpcal;
								read_loop: LOOP
									FETCH wkgpcal INTO caldt, calno, vat;
									IF done THEN
										LEAVE read_loop;
									END IF;
									
									SET logerr = CONCAT('[caltyp = mid] ', 'caldt=', caldt, ', calno=', calno, ', partno=', partno, ', po=', orderno);
									CALL InsertLog(logno, 'I-PGM', pgmid, pgmnm, pgmnm, logerr, usrnm, pgmidversion);



									CALL InsertRoCont_debug(partno, partname, model, custcd, dlvylc, caldt, dlvytm, shpdt, shptm, orderno, pdsno, dlvyno, IF(calno=1, qtyfst, qty), orderqty, truckno, orderdiv, slipdiv, shiftdiv, issdt, 
									rmk1, rmk2, rmk3, rmk4, rmk5, rmk6, rmk7, rmk8, rmk9, rmk10, rmk11, rmk12, filenm, shptyp, ponocnt, caltyp, usrnm, pgmid, pgmidversion, success, rono, clpln, currentNo, dlvylo2);

								END LOOP;
							CLOSE wkgpcal;
						END;
					WHEN 'last' THEN
						BEGIN
							DECLARE wkgpcal CURSOR FOR SELECT MAX(mwc.cal_date) as cal_date, @rownum:=@rownum+1 as rownum, mv.vat_percent FROM m_wkgp_calendars mwc 
								LEFT OUTER JOIN m_vat as mv ON mv.deleted_flg = 0 AND mv.vat_effdate <= mwc.cal_date AND mv.vat_expdate >= mwc.cal_date 
								WHERE mwc.holiday_flg = 0 AND mwc.deleted_flg = 0 AND mwc.work_place_cd = @shipment_place_cd AND mwc.cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND mwc.cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m');
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
							SET calcnt = (SELECT COUNT(*) FROM (SELECT MAX(cal_date) as cal_date FROM m_wkgp_calendars WHERE holiday_flg = 0 AND deleted_flg = 0 AND work_place_cd = @shipment_place_cd AND cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m')) calcnt);
							SET qtyfst = (FLOOR(orderqty / calcnt) + (orderqty - (FLOOR(orderqty / calcnt) * calcnt)));
							SET qty    = (FLOOR(orderqty / calcnt));
							OPEN wkgpcal;
								read_loop: LOOP
									FETCH wkgpcal INTO caldt, calno, vat;
									IF done THEN
										LEAVE read_loop;
									END IF;
									
									SET logerr = CONCAT('[caltyp = last] ', 'caldt=', caldt, ', calno=', calno, ', partno=', partno, ', po=', orderno);
									CALL InsertLog(logno, 'I-PGM', pgmid, pgmnm, pgmnm, logerr, usrnm, pgmidversion);



									CALL InsertRoCont_debug(partno, partname, model, custcd, dlvylc, caldt, dlvytm, shpdt, shptm, orderno, pdsno, dlvyno, IF(calno=1, qtyfst, qty), orderqty, truckno, orderdiv, slipdiv, shiftdiv, issdt, 
									rmk1, rmk2, rmk3, rmk4, rmk5, rmk6, rmk7, rmk8, rmk9, rmk10, rmk11, rmk12, filenm, shptyp, ponocnt, caltyp, usrnm, pgmid, pgmidversion, success, rono, clpln, currentNo, dlvylo2);
									
								END LOOP;
							CLOSE wkgpcal;
						END;
					WHEN 'mon' THEN
						BEGIN
							DECLARE wkgpcal CURSOR FOR SELECT mwc.cal_date, @rownum:=@rownum+1 as rownum, mv.vat_percent FROM m_wkgp_calendars mwc 
								LEFT OUTER JOIN m_vat as mv ON mv.deleted_flg = 0 AND mv.vat_effdate <= mwc.cal_date AND mv.vat_expdate >= mwc.cal_date 
								WHERE mwc.holiday_flg = 0 AND mwc.deleted_flg = 0 AND mwc.work_place_cd = @shipment_place_cd AND mwc.cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND mwc.cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND mwc.day_of_the_week = 1;
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
							SET calcnt = (SELECT COUNT(*) FROM (SELECT cal_date FROM m_wkgp_calendars WHERE holiday_flg = 0 AND deleted_flg = 0 AND work_place_cd = @shipment_place_cd AND cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND day_of_the_week = 1) calcnt);
							SET qtyfst = (FLOOR(orderqty / calcnt) + (orderqty - (FLOOR(orderqty / calcnt) * calcnt)));
							SET qty    = (FLOOR(orderqty / calcnt));
							OPEN wkgpcal;
								read_loop: LOOP
									FETCH wkgpcal INTO caldt, calno, vat;
									IF done THEN
										LEAVE read_loop;
									END IF;
									
									SET logerr = CONCAT('[caltyp = mon] ', 'caldt=', caldt, ', calno=', calno, ', partno=', partno, ', po=', orderno);
									CALL InsertLog(logno, 'I-PGM', pgmid, pgmnm, pgmnm, logerr, usrnm, pgmidversion);



									CALL InsertRoCont_debug(partno, partname, model, custcd, dlvylc, caldt, dlvytm, shpdt, shptm, orderno, pdsno, dlvyno, IF(calno=1, qtyfst, qty), orderqty, truckno, orderdiv, slipdiv, shiftdiv, issdt, 
									rmk1, rmk2, rmk3, rmk4, rmk5, rmk6, rmk7, rmk8, rmk9, rmk10, rmk11, rmk12, filenm, shptyp, ponocnt, caltyp, usrnm, pgmid, pgmidversion, success, rono, clpln, currentNo, dlvylo2);

								END LOOP;
							CLOSE wkgpcal;
						END;
					WHEN 'tue' THEN
						BEGIN
							DECLARE wkgpcal CURSOR FOR SELECT mwc.cal_date, @rownum:=@rownum+1 as rownum, mv.vat_percent FROM m_wkgp_calendars mwc 
								LEFT OUTER JOIN m_vat as mv ON mv.deleted_flg = 0 AND mv.vat_effdate <= mwc.cal_date AND mv.vat_expdate >= mwc.cal_date 
								WHERE mwc.holiday_flg = 0 AND mwc.deleted_flg = 0 AND mwc.work_place_cd = @shipment_place_cd AND mwc.cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND mwc.cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND mwc.day_of_the_week = 2;
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
							SET calcnt = (SELECT COUNT(*) FROM (SELECT cal_date FROM m_wkgp_calendars WHERE holiday_flg = 0 AND deleted_flg = 0 AND work_place_cd = @shipment_place_cd AND cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND day_of_the_week = 2) calcnt);
							SET qtyfst = (FLOOR(orderqty / calcnt) + (orderqty - (FLOOR(orderqty / calcnt) * calcnt)));
							SET qty    = (FLOOR(orderqty / calcnt));
							OPEN wkgpcal;
								read_loop: LOOP
									FETCH wkgpcal INTO caldt, calno, vat;
									IF done THEN
										LEAVE read_loop;
									END IF;
									
									SET logerr = CONCAT('[caltyp = tue] ', 'caldt=', caldt, ', calno=', calno, ', partno=', partno, ', po=', orderno);
									CALL InsertLog(logno, 'I-PGM', pgmid, pgmnm, pgmnm, logerr, usrnm, pgmidversion);



									CALL InsertRoCont_debug(partno, partname, model, custcd, dlvylc, caldt, dlvytm, shpdt, shptm, orderno, pdsno, dlvyno, IF(calno=1, qtyfst, qty), orderqty, truckno, orderdiv, slipdiv, shiftdiv, issdt, 
									rmk1, rmk2, rmk3, rmk4, rmk5, rmk6, rmk7, rmk8, rmk9, rmk10, rmk11, rmk12, filenm, shptyp, ponocnt, caltyp, usrnm, pgmid, pgmidversion, success, rono, clpln, currentNo, dlvylo2);

								END LOOP;
							CLOSE wkgpcal;
						END;
					WHEN 'wed' THEN
						BEGIN
							DECLARE wkgpcal CURSOR FOR SELECT mwc.cal_date, @rownum:=@rownum+1 as rownum, mv.vat_percent FROM m_wkgp_calendars mwc 
								LEFT OUTER JOIN m_vat as mv ON mv.deleted_flg = 0 AND mv.vat_effdate <= mwc.cal_date AND mv.vat_expdate >= mwc.cal_date 
								WHERE mwc.holiday_flg = 0 AND mwc.deleted_flg = 0 AND mwc.work_place_cd = @shipment_place_cd AND mwc.cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND mwc.cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND mwc.day_of_the_week = 3;
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
							SET calcnt = (SELECT COUNT(*) FROM (SELECT cal_date FROM m_wkgp_calendars WHERE holiday_flg = 0 AND deleted_flg = 0 AND work_place_cd = @shipment_place_cd AND cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND day_of_the_week = 3) calcnt);
							SET qtyfst = (FLOOR(orderqty / calcnt) + (orderqty - (FLOOR(orderqty / calcnt) * calcnt)));
							SET qty    = (FLOOR(orderqty / calcnt));
							OPEN wkgpcal;
								read_loop: LOOP
									FETCH wkgpcal INTO caldt, calno, vat;
									IF done THEN
										LEAVE read_loop;
									END IF;
									
									SET logerr = CONCAT('[caltyp = wed] ', 'caldt=', caldt, ', calno=', calno, ', partno=', partno, ', po=', orderno);
									CALL InsertLog(logno, 'I-PGM', pgmid, pgmnm, pgmnm, logerr, usrnm, pgmidversion);



									CALL InsertRoCont_debug(partno, partname, model, custcd, dlvylc, caldt, dlvytm, shpdt, shptm, orderno, pdsno, dlvyno, IF(calno=1, qtyfst, qty), orderqty, truckno, orderdiv, slipdiv, shiftdiv, issdt, 
									rmk1, rmk2, rmk3, rmk4, rmk5, rmk6, rmk7, rmk8, rmk9, rmk10, rmk11, rmk12, filenm, shptyp, ponocnt, caltyp, usrnm, pgmid, pgmidversion, success, rono, clpln, currentNo, dlvylo2);

								END LOOP;
							CLOSE wkgpcal;
						END;
					WHEN 'thu' THEN
						BEGIN
							DECLARE wkgpcal CURSOR FOR SELECT mwc.cal_date, @rownum:=@rownum+1 as rownum, mv.vat_percent FROM m_wkgp_calendars mwc 
								LEFT OUTER JOIN m_vat as mv ON mv.deleted_flg = 0 AND mv.vat_effdate <= mwc.cal_date AND mv.vat_expdate >= mwc.cal_date 
								WHERE mwc.holiday_flg = 0 AND mwc.deleted_flg = 0 AND mwc.work_place_cd = @shipment_place_cd AND mwc.cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND mwc.cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND mwc.day_of_the_week = 4;
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
							SET calcnt = (SELECT COUNT(*) FROM (SELECT cal_date FROM m_wkgp_calendars WHERE holiday_flg = 0 AND deleted_flg = 0 AND work_place_cd = @shipment_place_cd AND cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND day_of_the_week = 4) calcnt);
							SET qtyfst = (FLOOR(orderqty / calcnt) + (orderqty - (FLOOR(orderqty / calcnt) * calcnt)));
							SET qty    = (FLOOR(orderqty / calcnt));
							OPEN wkgpcal;
								read_loop: LOOP
									FETCH wkgpcal INTO caldt, calno, vat;
									IF done THEN
										LEAVE read_loop;
									END IF;
									
									SET logerr = CONCAT('[caltyp = thu] ', 'caldt=', caldt, ', calno=', calno, ', partno=', partno, ', po=', orderno);
									CALL InsertLog(logno, 'I-PGM', pgmid, pgmnm, pgmnm, logerr, usrnm, pgmidversion);



									CALL InsertRoCont_debug(partno, partname, model, custcd, dlvylc, caldt, dlvytm, shpdt, shptm, orderno, pdsno, dlvyno, IF(calno=1, qtyfst, qty), orderqty, truckno, orderdiv, slipdiv, shiftdiv, issdt, 
									rmk1, rmk2, rmk3, rmk4, rmk5, rmk6, rmk7, rmk8, rmk9, rmk10, rmk11, rmk12, filenm, shptyp, ponocnt, caltyp, usrnm, pgmid, pgmidversion, success, rono, clpln, currentNo, dlvylo2);

								END LOOP;
							CLOSE wkgpcal;
						END;
					WHEN 'fri' THEN
						BEGIN
							DECLARE wkgpcal CURSOR FOR SELECT mwc.cal_date, @rownum:=@rownum+1 as rownum, mv.vat_percent FROM m_wkgp_calendars mwc 
								LEFT OUTER JOIN m_vat as mv ON mv.deleted_flg = 0 AND mv.vat_effdate <= mwc.cal_date AND mv.vat_expdate >= mwc.cal_date 
								WHERE mwc.holiday_flg = 0 AND mwc.deleted_flg = 0 AND mwc.work_place_cd = @shipment_place_cd AND mwc.cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND mwc.cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND mwc.day_of_the_week = 5;
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
							SET calcnt = (SELECT COUNT(*) FROM (SELECT cal_date FROM m_wkgp_calendars WHERE holiday_flg = 0 AND deleted_flg = 0 AND work_place_cd = @shipment_place_cd AND cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND day_of_the_week = 5) calcnt);
							SET qtyfst = (FLOOR(orderqty / calcnt) + (orderqty - (FLOOR(orderqty / calcnt) * calcnt)));
							SET qty    = (FLOOR(orderqty / calcnt));
							OPEN wkgpcal;
								read_loop: LOOP
									FETCH wkgpcal INTO caldt, calno, vat;
									IF done THEN
										LEAVE read_loop;
									END IF;
									
									SET logerr = CONCAT('[caltyp = fri] ', 'caldt=', caldt, ', calno=', calno, ', partno=', partno, ', po=', orderno);
									CALL InsertLog(logno, 'I-PGM', pgmid, pgmnm, pgmnm, logerr, usrnm, pgmidversion);



									CALL InsertRoCont_debug(partno, partname, model, custcd, dlvylc, caldt, dlvytm, shpdt, shptm, orderno, pdsno, dlvyno, IF(calno=1, qtyfst, qty), orderqty, truckno, orderdiv, slipdiv, shiftdiv, issdt, 
									rmk1, rmk2, rmk3, rmk4, rmk5, rmk6, rmk7, rmk8, rmk9, rmk10, rmk11, rmk12, filenm, shptyp, ponocnt, caltyp, usrnm, pgmid, pgmidversion, success, rono, clpln, currentNo, dlvylo2);

								END LOOP;
							CLOSE wkgpcal;
						END;
					WHEN 'sat' THEN
						BEGIN
							DECLARE wkgpcal CURSOR FOR SELECT mwc.cal_date, @rownum:=@rownum+1 as rownum, mv.vat_percent FROM m_wkgp_calendars mwc 
								LEFT OUTER JOIN m_vat as mv ON mv.deleted_flg = 0 AND mv.vat_effdate <= mwc.cal_date AND mv.vat_expdate >= mwc.cal_date 
								WHERE mwc.holiday_flg = 0 AND mwc.deleted_flg = 0 AND mwc.work_place_cd = @shipment_place_cd AND mwc.cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND mwc.cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND mwc.day_of_the_week = 6;
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
							SET calcnt = (SELECT COUNT(*) FROM (SELECT cal_date FROM m_wkgp_calendars WHERE holiday_flg = 0 AND deleted_flg = 0 AND work_place_cd = @shipment_place_cd AND cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND day_of_the_week = 6) calcnt);
							SET qtyfst = (FLOOR(orderqty / calcnt) + (orderqty - (FLOOR(orderqty / calcnt) * calcnt)));
							SET qty    = (FLOOR(orderqty / calcnt));
							OPEN wkgpcal;
								read_loop: LOOP
									FETCH wkgpcal INTO caldt, calno, vat;
									IF done THEN
										LEAVE read_loop;
									END IF;
									
									SET logerr = CONCAT('[caltyp = sat] ', 'caldt=', caldt, ', calno=', calno, ', partno=', partno, ', po=', orderno);
									CALL InsertLog(logno, 'I-PGM', pgmid, pgmnm, pgmnm, logerr, usrnm, pgmidversion);



									CALL InsertRoCont_debug(partno, partname, model, custcd, dlvylc, caldt, dlvytm, shpdt, shptm, orderno, pdsno, dlvyno, IF(calno=1, qtyfst, qty), orderqty, truckno, orderdiv, slipdiv, shiftdiv, issdt, 
									rmk1, rmk2, rmk3, rmk4, rmk5, rmk6, rmk7, rmk8, rmk9, rmk10, rmk11, rmk12, filenm, shptyp, ponocnt, caltyp, usrnm, pgmid, pgmidversion, success, rono, clpln, currentNo, dlvylo2);

								END LOOP;
							CLOSE wkgpcal;
						END;
					WHEN 'sun' THEN
						BEGIN
							DECLARE wkgpcal CURSOR FOR SELECT mwc.cal_date, @rownum:=@rownum+1 as rownum, mv.vat_percent FROM m_wkgp_calendars mwc 
								LEFT OUTER JOIN m_vat as mv ON mv.deleted_flg = 0 AND mv.vat_effdate <= mwc.cal_date AND mv.vat_expdate >= mwc.cal_date 
								WHERE mwc.holiday_flg = 0 AND mwc.deleted_flg = 0 AND mwc.work_place_cd = @shipment_place_cd AND mwc.cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND mwc.cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND mwc.day_of_the_week = 7;
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
							SET calcnt = (SELECT COUNT(*) FROM (SELECT cal_date FROM m_wkgp_calendars WHERE holiday_flg = 0 AND deleted_flg = 0 AND work_place_cd = @shipment_place_cd AND cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m') AND day_of_the_week = 7) calcnt);
							SET qtyfst = (FLOOR(orderqty / calcnt) + (orderqty - (FLOOR(orderqty / calcnt) * calcnt)));
							SET qty    = (FLOOR(orderqty / calcnt));
							OPEN wkgpcal;
								read_loop: LOOP
									FETCH wkgpcal INTO caldt, calno, vat;
									IF done THEN
										LEAVE read_loop;
									END IF;
									
									SET logerr = CONCAT('[caltyp = sun] ', 'caldt=', caldt, ', calno=', calno, ', partno=', partno, ', po=', orderno);
									CALL InsertLog(logno, 'I-PGM', pgmid, pgmnm, pgmnm, logerr, usrnm, pgmidversion);



									CALL InsertRoCont_debug(partno, partname, model, custcd, dlvylc, caldt, dlvytm, shpdt, shptm, orderno, pdsno, dlvyno, IF(calno=1, qtyfst, qty), orderqty, truckno, orderdiv, slipdiv, shiftdiv, issdt, 
									rmk1, rmk2, rmk3, rmk4, rmk5, rmk6, rmk7, rmk8, rmk9, rmk10, rmk11, rmk12, filenm, shptyp, ponocnt, caltyp, usrnm, pgmid, pgmidversion, success, rono, clpln, currentNo, dlvylo2);
									
								END LOOP;
							CLOSE wkgpcal;
						END;
					WHEN 'day' THEN
						BEGIN
							DECLARE wkgpcal CURSOR FOR SELECT mwc.cal_date, @rownum:=@rownum+1 as rownum, mv.vat_percent FROM m_wkgp_calendars mwc 
								LEFT OUTER JOIN m_vat as mv ON mv.deleted_flg = 0 AND mv.vat_effdate <= mwc.cal_date AND mv.vat_expdate >= mwc.cal_date 
								WHERE mwc.holiday_flg = 0 AND mwc.deleted_flg = 0 AND mwc.work_place_cd = @shipment_place_cd AND mwc.cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND mwc.cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m');
							DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
							SET calcnt = (SELECT COUNT(*) FROM (SELECT cal_date FROM m_wkgp_calendars WHERE holiday_flg = 0 AND deleted_flg = 0 AND work_place_cd = @shipment_place_cd AND cal_year = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%Y') AND cal_month = DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m'), '%m')) calcnt);
							SET qtyfst = (FLOOR(orderqty / calcnt) + (orderqty - (FLOOR(orderqty / calcnt) * calcnt)));
							SET qty    = (FLOOR(orderqty / calcnt));
							OPEN wkgpcal;
								read_loop: LOOP
									FETCH wkgpcal INTO caldt, calno, vat;
									IF done THEN
										LEAVE read_loop;
									END IF;
									
									SET logerr = CONCAT('[caltyp = day] ', 'caldt=', caldt, ', calno=', calno, ', partno=', partno, ', po=', orderno);
									CALL InsertLog(logno, 'I-PGM', pgmid, pgmnm, pgmnm, logerr, usrnm, pgmidversion);



									CALL InsertRoCont_debug(partno, partname, model, custcd, dlvylc, caldt, dlvytm, shpdt, shptm, orderno, pdsno, dlvyno, IF(calno=1, qtyfst, qty), orderqty, truckno, orderdiv, slipdiv, shiftdiv, issdt, 
									rmk1, rmk2, rmk3, rmk4, rmk5, rmk6, rmk7, rmk8, rmk9, rmk10, rmk11, rmk12, filenm, shptyp, ponocnt, caltyp, usrnm, pgmid, pgmidversion, success, rono, clpln, currentNo, dlvylo2);

								END LOOP;
							CLOSE wkgpcal;
						END;
					ELSE
						BEGIN
						END;
				END CASE;
            END IF;
		END IF;
	END IF;
END;

