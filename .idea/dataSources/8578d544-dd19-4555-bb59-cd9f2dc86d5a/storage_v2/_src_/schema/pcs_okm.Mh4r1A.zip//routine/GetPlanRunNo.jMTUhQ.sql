create
    definer = root@localhost procedure GetPlanRunNo(OUT planno varchar(50), OUT runno decimal(12))
BEGIN
	DECLARE running int default 1;
	SET  running = (SELECT serial_no + 1 FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'PRODUCT_PLAN');
	SELECT running INTO runno;
	IF running = 1 THEN SELECT concat(header_string, LPAD(1, digits, '0')) INTO planno FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'PRODUCT_PLAN' ;
	ELSE SELECT concat(header_string, LPAD(running, digits, '0'))  INTO planno FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'PRODUCT_PLAN'; 
	END IF;
END;

