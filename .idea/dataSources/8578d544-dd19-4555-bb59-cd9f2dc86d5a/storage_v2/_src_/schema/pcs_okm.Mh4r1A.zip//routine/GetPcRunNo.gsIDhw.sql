create
    definer = root@localhost procedure GetPcRunNo(OUT planno varchar(20))
BEGIN	
	DECLARE running int default 1;
    DECLARE pccnt int default 0;
    DECLARE footstr varchar(10);
	SELECT CONCAT(header_string, mns_footer_string, LPAD(mns_serial_no, digits, '0')) as runno, mns_footer_string, mns_serial_no INTO planno, footstr, running FROM (SELECT case when count(mns_serial_no) = 0 then 1 else mns_serial_no + 1 end as mns_serial_no, IFNULL(header_string, 'PC') as header_string, case when count(mns_serial_no) = 0 then DATE_FORMAT(now(), '%y%m') else mns_footer_string end as mns_footer_string, IFNULL(digits,6) as digits FROM m_numbers mn 
	LEFT OUTER JOIN (SELECT report_cd as mns_report_cd, serial_no as mns_serial_no, footer_string as mns_footer_string FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'PC' AND footer_string = DATE_FORMAT(now(), '%y%m')) mns on mn.report_cd = mns.mns_report_cd WHERE deleted_flg = 0 AND report_cd = 'PC') runno;
	IF planno != '' THEN
		SELECT IFNULL(COUNT(1), 0) INTO pccnt FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'PC';       
		IF pccnt = 0 THEN           
			INSERT INTO m_numbers (report_cd, serial_no, header_string, footer_string, start_no, end_no, digits, factory_cd, report_nm, yymmdd_digits, deleted_flg, user_id, program_id, created_datetime)           
            VALUES ('PC', running, 'PC', footstr, 1, 999999, 6, '', 'PURCHASE PLAN', 4, 0, 'Insert', 'GetPcRunNo', now());       
		ELSE           
			UPDATE m_numbers SET serial_no = running, footer_string = footstr, modified_datetime = now() WHERE deleted_flg = 0 AND report_cd = 'PC';       
		END IF; 
	END IF;
END;

