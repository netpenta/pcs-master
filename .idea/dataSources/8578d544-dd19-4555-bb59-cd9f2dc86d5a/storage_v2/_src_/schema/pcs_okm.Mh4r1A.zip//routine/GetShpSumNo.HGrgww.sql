create
    definer = root@localhost procedure GetShpSumNo(IN factcd varchar(50), IN shpdate int, OUT sumno varchar(20))
BEGIN
	DECLARE running int default 1;
    SET running = (SELECT CASE WHEN (SELECT COUNT(1) FROM sh_result WHERE factory_cd = factcd AND shipment_date = shpdate AND summary_no != '' AND delivery_location_nm2 IN ('0', '1')) = 0 THEN 1 ELSE (SELECT max(CAST(REPLACE(summary_no,'G','') AS decimal))+1 as summary_no FROM sh_result WHERE factory_cd = factcd AND shipment_date = shpdate AND summary_no != '' AND delivery_location_nm2 IN ('0', '1')) END);    
	IF running = 1 THEN SELECT CONCAT(header_string, SUBSTR(shpdate, 3), LPAD(running, digits, '0')) INTO sumno FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'SUMNO' AND factory_cd = factcd;	
    ELSE SELECT CONCAT(header_string, running) INTO sumno FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'SUMNO' and factory_cd = factcd;
	END IF;
END;

