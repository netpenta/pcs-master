create
    definer = root@localhost procedure GetPurchasePlanSummary(IN in_dodate_from int, IN in_dodate_to int,
                                                              IN in_factory_cd varchar(50),
                                                              IN in_item_cust_cd varchar(50), IN in_item_cd varchar(50),
                                                              IN in_item_revno varchar(50),
                                                              IN in_supplier_cd varchar(50), IN in_proc_cd varchar(50),
                                                              IN in_pagerow int, IN in_pagesize int)
BEGIN
SELECT  plan.summ_index, plan.summ_type, plan.item_cust_cd, plan.item_cd, plan.item_rev_no, IFNULL(good_stock_qtty,0) as prev_good_stock_qtty,
        @balance_qtty:= IF(summ_index =1, IFNULL(good_stock_qtty,0) + IFNULL(pur_prev_qtty,0), IF(summ_index =2, @balance_qtty + IFNULL(receipt_prev_qtty,0), IF(summ_index =3, @balance_qtty - IFNULL(prod_prev_qtty,0), IF(summ_index =4, @balance_qtty - IFNULL(ship_prev_qtty,0), @balance_qtty)))) as good_stock_qtty,
        IFNULL(IF(summ_index = 1, pur_prev_qtty , IF(summ_index = 2, receipt_prev_qtty , IF(summ_index = 3, prod_prev_qtty , IF(summ_index = 4, ship_prev_qtty , 0)))), 0) as summ_prev_qtty,
        IFNULL(IF(summ_index = 1, pur_total_qtty, IF(summ_index = 2, receipt_total_qtty, IF(summ_index = 3, prod_total_qtty, IF(summ_index = 4, ship_total_qtty, 0)))), 0) as summ_total_qtty,
        IFNULL(IF(summ_index = 1, pur_next_qtty , IF(summ_index = 2, receipt_next_qtty , IF(summ_index = 3, prod_next_qtty , IF(summ_index = 4, ship_next_qtty , 0)))), 0) as summ_next_qtty,
        IFNULL(IF(summ_index = 1, pur_summ_date , IF(summ_index = 2, receipt_summ_date , IF(summ_index = 3, prod_summ_date , IF(summ_index = 4, ship_summ_date , 0)))), 0) as summ_data_date,
        IFNULL(IF(summ_index = 1, pur_summ_qtty , IF(summ_index = 2, receipt_summ_qtty , IF(summ_index = 3, prod_summ_qtty , IF(summ_index = 4, ship_summ_qtty , 0)))), 0) as summ_data_qtty,
        IFNULL(IF(summ_index = 1, pur_summ_data , IF(summ_index = 2, receipt_summ_data , IF(summ_index = 3, prod_summ_data , IF(summ_index = 4, ship_summ_data , 0)))), 0) as summ_data
FROM(
	  SELECT DISTINCT summ_index, plan.level, summ_type, plan.item_cust_cd, plan.item_cd, plan.item_rev_no, good_stock_qtty FROM pur_data as plan
     CROSS JOIN(SELECT 1 as summ_index, 'PURCHASE' as summ_type UNION SELECT 2 as summ_index, 'RECEIPT' as summ_type UNION SELECT 3 as summ_index, 'PROD' as summ_type UNION SELECT 4 as summ_index, 'SHIP' as summ_type ) as typeofdata
     LEFT JOIN (
		   SELECT item_cust_cd, item_cd, item_rev_no, SUM(good_stock_qtty) as good_stock_qtty  FROM st_item WHERE  stock_yyyymm = 999999
		   GROUP  BY item_cust_cd, item_cd, item_rev_no HAVING SUM(good_stock_qtty) > 0
	  )as      stock ON stock.item_cust_cd = plan.item_cust_cd AND  stock.item_cd = plan.item_cd AND stock.item_rev_no = plan.item_rev_no
     WHERE    plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to AND expand_div = 0 AND proc_div = 4	AND finished_flg = 0
     AND      factory_cd_from = CASE WHEN LENGTH(in_factory_cd) > 0 THEN in_factory_cd ELSE factory_cd_from END
	  AND      plan.item_cust_cd LIKE CASE WHEN LENGTH(in_item_cust_cd) > 0 THEN in_item_cust_cd ELSE '%%' END
     AND      plan.item_cd LIKE CASE WHEN LENGTH(in_item_cd) > 0 THEN in_item_cd ELSE '%%' END
     AND      plan.item_rev_no LIKE CASE WHEN LENGTH(in_item_revno) > 0 THEN in_item_revno ELSE '%%' END
     AND      supplier_cd LIKE CASE WHEN LENGTH(in_supplier_cd) > 0 THEN in_supplier_cd ELSE '%%' END
     AND      plan.proc_cd = CASE WHEN LENGTH(in_proc_cd) > 0 THEN in_proc_cd ELSE plan.proc_cd END
	  ORDER BY plan.item_cd, summ_index, plan.level
)as plan JOIN (SELECT @balance_qtty:=0) AS define_variable
LEFT JOIN (
	  SELECT 1 as summ_index, item_cust_cd, item_cd, item_rev_no, SUM(pur_prev_qtty) as pur_prev_qtty, SUM(result_qtty) as pur_total_qtty, SUM(pur_next_qtty) as pur_next_qtty,
            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, plan_delivery_date, null) ORDER BY plan_delivery_date) as pur_summ_date,
            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, result_qtty       , null) ORDER BY plan_delivery_date) as pur_summ_qtty,
            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, CONCAT(result_qtty,'/',request_qtty) , null) ORDER BY plan_delivery_date) as pur_summ_data
     FROM(
			  SELECT   plan_delivery_date, item_cust_cd, item_cd, item_rev_no,
					   IF(plan_delivery_date  < in_dodate_from, SUM(request_remain_p_order_unit), 0) as pur_prev_qtty,
					   IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, SUM(request_remain_p_order_unit), 0) as result_qtty,
					   IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, SUM(request_qtty_p_order_unit)   , 0) as request_qtty,
					   IF(plan_delivery_date >  in_dodate_to  , SUM(request_remain_p_order_unit), 0) as pur_next_qtty
			  FROM     pur_data
             WHERE    plan_delivery_date >= (SELECT this_month_start_date FROM m_sys_admin ORDER BY this_month_start_date DESC LIMIT 1) AND finished_flg = 0
             AND      factory_cd_from = CASE WHEN LENGTH(in_factory_cd) > 0 THEN in_factory_cd ELSE factory_cd_from END
	          AND      item_cust_cd LIKE CASE WHEN LENGTH(in_item_cust_cd) > 0 THEN in_item_cust_cd ELSE '%%' END
             AND      item_cd LIKE CASE WHEN LENGTH(in_item_cd) > 0 THEN in_item_cd ELSE '%%' END
             AND      item_rev_no LIKE CASE WHEN LENGTH(in_item_revno) > 0 THEN in_item_revno ELSE '%%' END
             AND      supplier_cd LIKE CASE WHEN LENGTH(in_supplier_cd) > 0 THEN in_supplier_cd ELSE '%%' END
             AND      proc_cd = CASE WHEN LENGTH(in_proc_cd) > 0 THEN in_proc_cd ELSE proc_cd END
             GROUP BY plan_delivery_date, item_cust_cd, item_cd, item_rev_no
     )as pur_data GROUP BY item_cust_cd, item_cd, item_rev_no
)as purchase USING(summ_index, item_cust_cd, item_cd, item_rev_no)
LEFT JOIN (
	  SELECT 2 as summ_index, item_cust_cd, item_cd, item_rev_no, SUM(receipt_prev_qtty) as receipt_prev_qtty, SUM(receipt_qtty) as receipt_total_qtty, SUM(receipt_next_qtty) as receipt_next_qtty,
            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, plan_delivery_date, null) ORDER BY plan_delivery_date) as receipt_summ_date,
            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, receipt_qtty      , null) ORDER BY plan_delivery_date) as receipt_summ_qtty,
            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, CONCAT(receipt_qtty,'/',request_qtty) , null) ORDER BY plan_delivery_date) as receipt_summ_data
     FROM(
			  SELECT    plan_delivery_date, item_cust_cd, item_cd, item_rev_no,
					    IF(plan_delivery_date <  in_dodate_from, SUM(result_qtty_p_order_unit), 0) as receipt_prev_qtty,
					    IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, SUM(result_qtty_p_order_unit), 0)   as receipt_qtty,
					    IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, SUM(request_qtty_p_order_unit), 0)   as request_qtty,
					    IF(plan_delivery_date >  in_dodate_to  , SUM(result_qtty_p_order_unit), 0) as receipt_next_qtty
			  FROM      pur_result
             WHERE     plan_delivery_date >= (SELECT this_month_start_date FROM m_sys_admin ORDER BY this_month_start_date DESC LIMIT 1) AND plan_delivery_date <= CAST(DATE_FORMAT(DATE_ADD(STR_TO_DATE(in_dodate_to,'%Y%m%d'), interval 7 day),'%Y%m%d') as Decimal) AND finished_flg = 0
             AND       factory_cd_from = CASE WHEN LENGTH(in_factory_cd) > 0 THEN in_factory_cd ELSE factory_cd_from END
	          AND       item_cust_cd LIKE CASE WHEN LENGTH(in_item_cust_cd) > 0 THEN in_item_cust_cd ELSE '%%' END
             AND       item_cd LIKE CASE WHEN LENGTH(in_item_cd) > 0 THEN in_item_cd ELSE '%%' END
             AND       item_rev_no LIKE CASE WHEN LENGTH(in_item_revno) > 0 THEN in_item_revno ELSE '%%' END
             AND       supplier_cd LIKE CASE WHEN LENGTH(in_supplier_cd) > 0 THEN in_supplier_cd ELSE '%%' END
             AND       proc_cd = CASE WHEN LENGTH(in_proc_cd) > 0 THEN in_proc_cd ELSE proc_cd END
             GROUP BY  plan_delivery_date, item_cust_cd, item_cd, item_rev_no
     )as receipt_data GROUP BY item_cust_cd, item_cd, item_rev_no
)as receipt_data USING(summ_index, item_cust_cd, item_cd, item_rev_no)
LEFT JOIN (
	  SELECT 3 as summ_index, item_cust_cd, item_cd, item_rev_no, SUM(prod_prev_qtty) as prod_prev_qtty, SUM(request_remain) as prod_total_qtty, SUM(prod_next_qtty) as prod_next_qtty,
            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, plan_delivery_date, null) ORDER BY plan_delivery_date) as prod_summ_date,
            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, request_remain    , null) ORDER BY plan_delivery_date) as prod_summ_qtty,
            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, CONCAT(request_remain,'/',request_qtty) , null) ORDER BY plan_delivery_date) as prod_summ_data
     FROM(
			  SELECT    plan_delivery_date, item_cust_cd, item_cd, item_rev_no,
					    IF(plan_delivery_date < in_dodate_from, SUM(request_remain_struct_unit), 0) as prod_prev_qtty,
					    IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, SUM(request_remain_struct_unit), 0) as request_remain,
					    IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, SUM(request_qtty_struct_unit), 0)   as request_qtty,
					    IF(plan_delivery_date >  in_dodate_to  , SUM(request_remain_struct_unit), 0) as prod_next_qtty
			  FROM      pl_sched_detail
             WHERE     plan_delivery_date >= (SELECT this_month_start_date FROM m_sys_admin ORDER BY this_month_start_date DESC LIMIT 1) AND plan_delivery_date <= CAST(DATE_FORMAT(DATE_ADD(STR_TO_DATE(in_dodate_to,'%Y%m%d'), interval 7 day),'%Y%m%d') as Decimal) AND expand_div > 0 AND finished_flg = 0
             AND       factory_cd = CASE WHEN LENGTH(in_factory_cd) > 0 THEN in_factory_cd ELSE factory_cd END
	          AND       item_cust_cd LIKE CASE WHEN LENGTH(in_item_cust_cd) > 0 THEN in_item_cust_cd ELSE '%%' END
             AND       item_cd LIKE CASE WHEN LENGTH(in_item_cd) > 0 THEN in_item_cd ELSE '%%' END
             AND       item_rev_no LIKE CASE WHEN LENGTH(in_item_revno) > 0 THEN in_item_revno ELSE '%%' END
             GROUP BY  plan_delivery_date, item_cust_cd, item_cd, item_rev_no
     )as prod_data GROUP BY item_cust_cd, item_cd, item_rev_no
)as prod USING(summ_index, item_cust_cd, item_cd, item_rev_no)
LEFT JOIN (
	  SELECT 4 as summ_index, item_cust_cd, item_cd, item_rev_no, SUM(ship_prev_qtty) as ship_prev_qtty, SUM(s_order_remain) as ship_total_qtty, SUM(ship_next_qtty) as ship_next_qtty,
            GROUP_CONCAT(IF(delivery_date >= in_dodate_from AND delivery_date <= in_dodate_to, delivery_date, null) ORDER BY delivery_date) as ship_summ_date,
            GROUP_CONCAT(IF(delivery_date >= in_dodate_from AND delivery_date <= in_dodate_to, s_order_remain , null) ORDER BY delivery_date) as ship_summ_qtty,
            GROUP_CONCAT(IF(delivery_date >= in_dodate_from AND delivery_date <= in_dodate_to, CONCAT(s_order_remain,'/',s_order_qtty) , null) ORDER BY delivery_date) as ship_summ_data
     FROM(
			   SELECT   delivery_date, item_cust_cd, item_cd, item_rev_no,
					    IF(delivery_date < in_dodate_from, SUM(s_order_remain_s_order_unit), 0) as ship_prev_qtty,
					    IF(delivery_date >= in_dodate_from AND delivery_date <= in_dodate_to, SUM(s_order_remain_s_order_unit), 0) as s_order_remain,
					    IF(delivery_date >= in_dodate_from AND delivery_date <= in_dodate_to, SUM(s_order_qtty_s_order_unit)  , 0) as s_order_qtty,
					    IF(delivery_date >  in_dodate_to  , SUM(s_order_remain_s_order_unit), 0) as ship_next_qtty
			  FROM      ro_data
             WHERE     delivery_date >= (SELECT this_month_start_date FROM m_sys_admin ORDER BY this_month_start_date DESC LIMIT 1) AND delivery_date <= CAST(DATE_FORMAT(DATE_ADD(STR_TO_DATE(in_dodate_to,'%Y%m%d'), interval 7 day),'%Y%m%d') as Decimal) AND finished_flg = 0
	          AND       item_cust_cd LIKE CASE WHEN LENGTH(in_item_cust_cd) > 0 THEN in_item_cust_cd ELSE '%%' END
             AND       item_cd LIKE CASE WHEN LENGTH(in_item_cd) > 0 THEN in_item_cd ELSE '%%' END
             AND       item_rev_no LIKE CASE WHEN LENGTH(in_item_revno) > 0 THEN in_item_revno ELSE '%%' END
             GROUP BY  delivery_date, item_cust_cd, item_cd, item_rev_no
     )as ro_data GROUP BY item_cust_cd, item_cd, item_rev_no
)as ship USING(summ_index, item_cust_cd, item_cd, item_rev_no) ORDER BY plan.item_cd ASC, summ_index;
END;

