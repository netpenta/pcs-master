create
    definer = root@localhost function GetMnumber(param_report_cd varchar(50), param_factory_cd varchar(50)) returns text
BEGIN
	 DECLARE var_serial_no    INT default 1;  
	 DECLARE found_serial_no  INT default 0; 
	 DECLARE var_footer_no  VARCHAR(50) DEFAULT ''; 
	 DECLARE var_header_str VARCHAR(50) DEFAULT ''; 
	 DECLARE var_report_no  VARCHAR(50) DEFAULT '';  	 
	 DECLARE var_report_cd  VARCHAR(50) DEFAULT param_report_cd; 
	 DECLARE return_value   TEXT DEFAULT '';  	 
	 

    SET var_report_cd  = (SELECT CONCAT(report_cd, DATE_FORMAT(NOW(), IFNULL(format_yyyymmdd, DATE_FORMAT(NOW(), CASE WHEN yymmdd_digits = 6 THEN '%y%m%d' WHEN yymmdd_digits = 4 THEN '%y%m' ELSE '' END)  )))  FROM m_numbers WHERE report_cd = param_report_cd AND IFNULL(factory_cd,'') = param_factory_cd);
    
	 SET found_serial_no= (SELECT EXISTS (SELECT serial_no FROM m_numbers WHERE deleted_flg = 0 AND report_cd = var_report_cd));
	 
	 IF found_serial_no = 1 THEN
	 	 SET var_serial_no = (SELECT serial_no FROM m_numbers WHERE deleted_flg = 0 AND report_cd = var_report_cd) + 1;
	 ELSE 
	 	 SET var_serial_no = 1;	 	 
	 END IF;
	 
    SET var_header_str = (SELECT header_string  FROM m_numbers WHERE deleted_flg = 0 AND report_cd = var_report_cd); 

    IF  var_serial_no  = 1 THEN 
    	  SET var_header_str = (SELECT CONCAT(header_string , DATE_FORMAT(NOW(), IFNULL(format_yyyymmdd, DATE_FORMAT(NOW(), CASE WHEN yymmdd_digits = 6 THEN '%y%m%d' WHEN yymmdd_digits = 4 THEN '%y%m' ELSE '' END)  )))  FROM m_numbers WHERE deleted_flg = 0 AND IFNULL(factory_cd,'') = param_factory_cd AND report_cd = param_report_cd);     	  
    	  SET var_report_no  = (SELECT CONCAT(var_header_str, (CASE WHEN report_cd = 'PUR_DATA' THEN '-' WHEN report_cd = 'PRODUCT_PLAN' THEN '-' ELSE footer_string END) , LPAD(var_serial_no, digits, '0')) FROM m_numbers WHERE deleted_flg = 0 AND report_cd = param_report_cd);
    	  
    	  SET return_value   = (SELECT JSON_OBJECT('report_cd', var_report_cd, 'serial_no', var_serial_no, 'header_string', var_header_str, 'report_no', var_report_no, 'start_no', start_no, 'footer_string', footer_string, 'end_no', end_no, 'digits', digits, 'factory_cd', factory_cd, 'report_nm', report_nm, 'yymmdd_digits', yymmdd_digits) FROM m_numbers WHERE deleted_flg = 0 AND IFNULL(factory_cd,'') = param_factory_cd AND report_cd = param_report_cd);
    ELSE
    	  SET var_report_no  = (SELECT CONCAT(var_header_str, (CASE WHEN report_cd LIKE '%PUR_DATA%' THEN '-' WHEN report_cd LIKE '%PRODUCT_PLAN%' THEN '-' ELSE footer_string END), LPAD(var_serial_no, digits, '0')) FROM m_numbers WHERE deleted_flg = 0 AND report_cd = var_report_cd);
    	  SET return_value   = (SELECT JSON_OBJECT('report_cd', var_report_cd, 'serial_no', var_serial_no, 'header_string', var_header_str, 'report_no', var_report_no, 'start_no', start_no, 'footer_string', footer_string, 'end_no', end_no, 'digits', digits, 'factory_cd', factory_cd, 'report_nm', report_nm, 'yymmdd_digits', yymmdd_digits) FROM m_numbers WHERE deleted_flg = 0 AND IFNULL(factory_cd,'') = param_factory_cd AND report_cd = var_report_cd);
    END IF;

  
    
   
    RETURN return_value;
END;

