create
    definer = root@localhost procedure GetDnRunNo(IN factcd varchar(50), IN dndate int, OUT dnhdno varchar(50),
                                                  OUT runno int)
BEGIN	
         DECLARE running int default 1;    
         SET running = (SELECT CASE WHEN (SELECT COUNT(1) FROM dn_doc_header WHERE dn_factory_cd = factcd AND DATE_FORMAT(STR_TO_DATE(dn_issued_date, '%Y%m%d'), '%y%m') = DATE_FORMAT(STR_TO_DATE(dndate, '%Y%m%d'), '%y%m')) = 0 THEN 1 ELSE (SELECT max(delivery_no)+1 as delivery_no FROM dn_doc_header WHERE dn_factory_cd = factcd AND DATE_FORMAT(STR_TO_DATE(dn_issued_date, '%Y%m%d'), '%y%m') = DATE_FORMAT(STR_TO_DATE(dndate, '%Y%m%d'), '%y%m')) END);    
         SELECT running INTO runno;
         IF running = 1 THEN SELECT CONCAT(header_string, DATE_FORMAT(STR_TO_DATE(dndate, '%Y%m%d'), '%y%m'), LPAD(running, IF(digits=0, 5, IFNULL(digits, 5)), '0')) INTO dnhdno FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'DNDOC' AND factory_cd = factcd;	
         ELSE SELECT CONCAT(header_string, DATE_FORMAT(STR_TO_DATE(dndate, '%Y%m%d'), '%y%m'), LPAD(running, IF(digits=0, 5, IFNULL(digits, 5)), '0')) INTO dnhdno FROM m_numbers WHERE deleted_flg = 0 ANd report_cd = 'DNDOC' AND factory_cd = factcd; 	
         END IF;
END;

