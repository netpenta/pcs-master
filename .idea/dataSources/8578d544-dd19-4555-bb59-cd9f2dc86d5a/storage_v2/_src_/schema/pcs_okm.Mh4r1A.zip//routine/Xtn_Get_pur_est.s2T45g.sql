create
    definer = root@localhost procedure Xtn_Get_pur_est(IN xitem_cd varchar(50), IN xsdt int)
BEGIN
SELECT @rownum := @rownum + 1 as id_no, t.item_cd, t.plan_delivery_date, FLOOR(t.plan_qtty) AS prod_qtty, FLOOR(t.request_qtty) AS pur_qtty 
       , FLOOR(  @sum_total:= @sum_total - t.plan_qtty + t.request_qtty)  AS Total , t.pr_no , t.po_no 
       , t.price, t.work_place_cd 
 FROM (  
 		    (   SELECT st.item_cd, st.this_month_start_date AS plan_delivery_date, 0 AS plan_qtty,  st.good_stock_qtty AS request_qtty 
 		    , 'STOCK' AS pr_no, 'NOW' AS po_no, 0 AS price, st.work_place_cd 
 		    FROM st_item st  
 		    WHERE st.stock_yyyymm = 999999     
 		    AND st.item_cd REGEXP xitem_cd 
          )  		UNION ALL 
 		    (   SELECT p.item_cd, p.plan_delivery_date, FLOOR(SUM(p.request_qtty_struct_unit)) AS plan_qtty, FLOOR(SUM(IFNULL(pu.request_qtty,0))) AS request_qtty 
 		    , IFNULL(pu.pr_no,'') AS pr_no , IFNULL(pu.po_no,'') AS po_no, (mpp.p_order_unit_price) AS price, mpp.supplier_cd as work_place_cd 
 		    FROM pl_sched_detail p  
 		    LEFT JOIN pur_data pu ON p.item_cust_cd = pu.item_cust_cd AND p.item_cd = pu.item_cd AND p.item_rev_no = pu.item_rev_no AND p.plan_delivery_date = pu.plan_delivery_date  
          LEFT JOIN m_purchase_prices mpp ON pu.item_cust_cd = mpp.item_cust_cd AND pu.item_cd = mpp.item_cd AND pu.item_rev_no = mpp.item_rev_no  
                      And pu.plan_delivery_date >= mpp.effect_date And pu.plan_delivery_date <= mpp.exp_date  
 		    WHERE p.plan_delivery_date >= xsdt  
 		    AND p.item_cd REGEXP xitem_cd
  	    GROUP BY p.item_cust_cd, p.item_cd, p.item_rev_no,  p.plan_delivery_date )  
 		    ) AS t  
 		JOIN (SELECT  @sum_total:=0) r   
 		, (SELECT @rownum := 0) s 
 		WHERE t.item_cd REGEXP xitem_cd
 		ORDER BY t.item_cd, t.plan_delivery_date ;    
END;

