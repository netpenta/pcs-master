create
    definer = root@localhost procedure GetOrderRunNo(OUT rono varchar(50), OUT runno int)
BEGIN
	DECLARE running int default 1;
	SET  running = (SELECT CASE WHEN (SELECT COUNT(1) FROM ro_data WHERE DATE_FORMAT(STR_TO_DATE(s_order_date, '%Y%m%d'), '%Y%m') = DATE_FORMAT(NOW(), '%Y%m')) = 0 THEN 1 ELSE (SELECT serial_no + 1 FROM m_numbers WHERE report_cd = 'RO') END);
	SELECT running INTO runno;
	IF running = 1 THEN SELECT concat(header_string, DATE_FORMAT(NOW(),'%y%m') , LPAD(1, digits, '0')) INTO rono FROM m_numbers WHERE report_cd = 'RO' ;
	ELSE SELECT concat(header_string, DATE_FORMAT(NOW(),'%y%m') , LPAD(running, digits, '0'))  INTO rono FROM m_numbers WHERE report_cd = 'RO'; 
	END IF;
END;

