create
    definer = root@localhost function CalculateGoodStockQttyByItem(param_this_month_start_date int,
                                                                   param_this_month_end_date int,
                                                                   param_item_cust_cd varchar(50),
                                                                   param_item_cd varchar(250),
                                                                   param_item_rev_no varchar(50),
                                                                   param_proc_cd varchar(50),
                                                                   param_place_cd varchar(50)) returns decimal(13, 3)
BEGIN
   DECLARE first_stock_qtty DECIMAL(13,3);   
	SET first_stock_qtty = IFNULL((
		SELECT   SUM((CASE WHEN inout_div in (11,21)       THEN inout_qtty  WHEN inout_div in (81) and inout_qtty >= 0 THEN inout_qtty ELSE 0 END)) 
             - SUM((CASE WHEN inout_div in (41,51,53)    THEN inout_qtty  WHEN inout_div in (12,42) THEN inout_qtty * -1 WHEN inout_div in (81) and inout_qtty < 0 THEN inout_qtty * -1 ELSE 0 END)) 
	   FROM st_lot_inout 
	   WHERE inout_date >= param_this_month_start_date AND inout_date <= param_this_month_end_date
	   AND   item_cust_cd = param_item_cust_cd AND item_cd = param_item_cd AND item_rev_no = param_item_rev_no AND proc_cd = param_proc_cd AND place_cd = param_place_cd
      GROUP BY place_cd, proc_cd, item_cust_cd, item_cd, item_rev_no
	), 0.000);
	RETURN first_stock_qtty;
END;

