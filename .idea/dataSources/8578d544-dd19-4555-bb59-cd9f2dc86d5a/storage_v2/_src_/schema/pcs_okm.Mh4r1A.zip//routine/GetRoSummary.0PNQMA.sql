create
    definer = root@localhost procedure GetRoSummary(IN in_dodate_from int, IN in_dodate_to int,
                                                    IN in_fact_cd varchar(50), IN in_order_no varchar(50),
                                                    IN in_order_type int, IN in_cust_cd varchar(50),
                                                    IN in_branch_cd varchar(50), IN in_cust_item_cd varchar(50),
                                                    IN in_page_row int, IN in_page_size int)
BEGIN
       SELECT @itemno:=IF(@tempcode = CONCAT(ro.item_cd, '-',ro.item_rev_no), @itemno + 1, 1) as summ_item_no, @tempcode:=CONCAT(ro.item_cd, '-', ro.item_rev_no) , ro.cust_cd, ro.branch_cd, ro.cust_serial_no, ro.item_cust_cd, ro.item_cd, ro.item_rev_no, ro.cust_item_cd, ro.summ_total, IFNULL(summ_next,0) as summ_next, ro.summ_data FROM(
		       SELECT cust_cd, branch_cd, cust_serial_no, item_cust_cd, item_cd, item_rev_no, cust_item_cd, SUM(COALESCE(s_order_remain_s_order_unit)) as summ_total,
				      GROUP_CONCAT(CONCAT(delivery_date, ':', s_order_remain_s_order_unit)) as summ_data
				 FROM(
		           SELECT  delivery_date, cust_cd, branch_cd, cust_serial_no, item_cust_cd, item_cd, item_rev_no, cust_item_cd, SUM(COALESCE(s_order_remain_s_order_unit)) as s_order_remain_s_order_unit	FROM ro_data as ro
			        WHERE ro.delivery_date >= in_dodate_from AND ro.delivery_date <= in_dodate_to
                 AND ro.factory_cd = CASE WHEN LENGTH(in_fact_cd) > 0 THEN in_fact_cd ELSE ro.factory_cd END
					  AND ro.s_order_no LIKE CASE WHEN LENGTH(in_order_no) > 0 THEN in_order_no ELSE '%%' END
					  AND ro.s_order_div = CASE WHEN in_order_type >= 0 THEN in_order_type ELSE ro.s_order_div END
					  AND ro.cust_cd LIKE CASE WHEN LENGTH(in_cust_cd) > 0 THEN in_cust_cd ELSE '%%' END
					  AND ro.branch_cd LIKE CASE WHEN LENGTH(in_branch_cd) > 0 THEN in_branch_cd ELSE '%%' END
					  AND ro.cust_item_cd LIKE CASE WHEN LENGTH(in_cust_item_cd) > 0 THEN in_cust_item_cd ELSE '%%' END
		           GROUP BY delivery_date, cust_cd, branch_cd, cust_serial_no, item_cust_cd, item_cd, item_rev_no, cust_item_cd
		           LIMIT in_page_row, in_page_size
		       )as ro_data GROUP BY cust_cd, branch_cd, cust_serial_no, item_cust_cd, item_cd, item_rev_no, cust_item_cd
		)as ro
		JOIN (SELECT @tempcode:=NULL, @itemno:=0) AS definegroup
		LEFT JOIN (
			SELECT cust_cd ,branch_cd, cust_serial_no, item_cust_cd, item_cd, item_rev_no, cust_item_cd, SUM(COALESCE(s_order_remain_s_order_unit)) as summ_next
			FROM ro_data WHERE delivery_date > in_dodate_to GROUP BY cust_cd ,branch_cd, cust_serial_no, item_cust_cd, item_cd, item_rev_no, cust_item_cd
      ) as next USING (cust_cd ,branch_cd, cust_serial_no, item_cust_cd, item_cd, item_rev_no, cust_item_cd)
      ORDER BY cust_item_cd, cust_cd, branch_cd ASC;
END;

