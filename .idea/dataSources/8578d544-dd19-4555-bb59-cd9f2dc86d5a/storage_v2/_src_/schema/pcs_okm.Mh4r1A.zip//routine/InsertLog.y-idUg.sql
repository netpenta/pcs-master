create
    definer = root@localhost procedure InsertLog(IN logno varchar(20), IN logtyp varchar(10), IN pgmid varchar(45),
                                                 IN pgmnm varchar(100), IN msgkey varchar(100), IN msg varchar(500),
                                                 IN usrnm varchar(50), IN pgmidversion varchar(100))
BEGIN
	INSERT m_pd_log SET
    
    log_type			= logtyp,
    log_program_id		= pgmid,
    log_program_name	= pgmnm,
    log_message_key		= msgkey,
    log_message			= msg,
    user_id				= usrnm,
    program_id			= pgmidversion,
    created_datetime	= now();
END;

