create
    definer = root@localhost function ConvertTimeNumeric(param_time_numeric decimal(6), param_time_format varchar(10)) returns varchar(20)
BEGIN
   DECLARE time_str VARCHAR(20);   
	SET time_str = IFNULL(TIME_FORMAT((CASE WHEN STR_TO_DATE(RPAD(param_time_numeric, 5, '0'), '%H%i%s') IS NULL THEN STR_TO_DATE(LPAD(RPAD(param_time_numeric, 5, '0'), 6, '0'), '%H%i%s') ELSE STR_TO_DATE(RPAD(param_time_numeric, 5, '0'), '%H%i%s') END), param_time_format), '');
	RETURN time_str;
END;

