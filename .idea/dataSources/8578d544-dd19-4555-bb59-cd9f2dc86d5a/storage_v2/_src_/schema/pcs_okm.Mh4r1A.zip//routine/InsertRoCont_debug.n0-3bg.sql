create
    definer = root@localhost procedure InsertRoCont_debug(IN partno varchar(50), IN partname varchar(300),
                                                          IN model varchar(20), IN custcd varchar(50),
                                                          IN dlvylc varchar(50), IN dlvydt decimal(8),
                                                          IN dlvytm decimal(6), IN shpdt decimal(8),
                                                          IN shptm decimal(6), IN orderno varchar(50),
                                                          IN pdsno varchar(50), IN dlvyno varchar(50),
                                                          IN orderqty decimal(13, 3), IN forecast decimal(13, 3),
                                                          IN truckno varchar(50), IN orderdiv decimal(3),
                                                          IN slipdiv decimal(3), IN shiftdiv decimal(3),
                                                          IN issdt decimal(8), IN rmk1 varchar(50), IN rmk2 varchar(50),
                                                          IN rmk3 varchar(50), IN rmk4 varchar(50), IN rmk5 varchar(50),
                                                          IN rmk6 varchar(50), IN rmk7 varchar(50), IN rmk8 varchar(50),
                                                          IN rmk9 varchar(50), IN rmk10 varchar(50),
                                                          IN rmk11 varchar(50), IN rmk12 varchar(50),
                                                          IN filenm varchar(300), IN shptyp decimal(3), IN ponocnt int,
                                                          IN caltyp varchar(20), IN usrnm varchar(50),
                                                          IN pgmid varchar(50), IN pgmidversion varchar(100),
                                                          OUT success int, OUT newrono varchar(20), OUT clpln int,
                                                          INOUT currentNo varchar(20), IN dlvylo2 varchar(50))
BEGIN
    DECLARE foundrow int default 0;
    DECLARE checkrow int default 0;
    DECLARE running int default 1;
    DECLARE rono varchar(20);
    DECLARE robrno int default 1;
    DECLARE shpqtty double;
    DECLARE oridlvydt int;
    DECLARE oridlvytm int;
    DECLARE orisqtty double;
    DECLARE smodel varchar(50);
    DECLARE logno varchar(20);
    DECLARE logerr varchar(500);
    DECLARE pgmnm varchar(100) default 'Receiving Order';
    DECLARE priqtty double;
    DECLARE mrpqtty double;
    DECLARE kdlotno varchar(100);
    SET success = 0;
    SET newrono = '';
    SET clpln = 0;
    
	SELECT @cust_cd:=msp.cust_cd, @branch_cd:=msp.branch_cd, @cust_serial_no:=mc.cust_serial_no, msp.cust_item_cd, @sales_item_prices_serial_no:=msp.serial_no, @item_cust_cd:=msp.item_cust_cd, @item_cd:=msp.item_cd, @item_rev_no:=msp.item_rev_no, 
	@boi_div:=msp.boi_div, @sales_unit_price:=msp.sales_unit_price, @vat_cd:=msp.vat_cd, @vat_div:=msp.vat_div, @vat_included_in_unit_price:=msp.vat_included_in_unit_price, @billing_cust_cd:=mc.billing_cust_cd, @billing_branch_cd:=mc.billing_branch_cd, @billing_cust_serial_no:=mc.billing_cust_serial_no, @round_div:=mc.round_div, @sales_person_cd:=mc.employee_cd, 
	@item_nm1:=mi.item_nm1, @shipment_place_cd:=mi.shipment_place_cd, 
	
   @model_cd_s_order:= IF(model = '' or model is null, IF(msp.model_cd = '' or msp.model_cd is null, mi.model_nm, msp.model_cd), model),  
	@s_order_rate:=mi.s_order_rate, @std_unit_cost:=mi.std_unit_cost, @pur_div:=(case when mip.proc_div = 4 then 1 else 0 end) as proc_div, @holiday_flg:=mwc.holiday_flg, @division_cd:=mp.division_cd, @factory_cd:=mp.factory_cd, @mi_item_cd:=mi.item_cd, @mi_item_rev_no:=mi.item_rev_no, @work_place_cd:=mwc.work_place_cd, 
    @vat_percent:=IFNULL(mv.vat_percent,0), 
	@shipment_date:=(DATE_FORMAT(DATE_ADD(STR_TO_DATE(dlvydt, '%Y%m%d'), INTERVAL -(mc.delivery_lead_time) DAY),'%Y%m%d')),
	@s_order_qtty:=IF(IFNULL(mi.s_order_rate,0)=0, orderqty, (orderqty / mi.s_order_rate)) 
	FROM m_sales_prices msp
	LEFT OUTER JOIN (
		SELECT cust_cd as mc_cust_cd, branch_cd as mc_branch_cd, serial_no as cust_serial_no, billing_cust_cd, billing_branch_cd, delivery_lead_time, employee_cd, billing_cust_serial_no, mcb_round_div as round_div FROM m_customers mc
		LEFT OUTER JOIN (
			SELECT cust_cd as mcb_cust_cd, branch_cd as mcb_branch_cd, serial_no as billing_cust_serial_no, round_div as mcb_round_div FROM m_customers WHERE deleted_flg = 0 AND effect_date <= dlvydt AND exp_date >= dlvydt
		) mcb ON mc.billing_cust_cd = mcb.mcb_cust_cd AND mc.billing_branch_cd = mcb.mcb_branch_cd
		WHERE deleted_flg = 0 AND effect_date <= dlvydt AND exp_date >= dlvydt
	) mc ON msp.cust_cd = mc.mc_cust_cd AND msp.branch_cd = mc.mc_branch_cd
    LEFT OUTER JOIN m_items as mi ON mi.deleted_flg = 0 AND msp.item_cust_cd = mi.item_cust_cd AND msp.item_cd = mi.item_cd AND msp.item_rev_no = mi.item_rev_no
    LEFT OUTER JOIN m_item_procs as mip ON mip.sort_no = 1 AND mip.deleted_flg = 0 AND msp.item_cust_cd = mip.item_cust_cd AND msp.item_cd = mip.item_cd AND msp.item_rev_no = mip.item_rev_no
    LEFT OUTER JOIN m_wkgp_calendars as mwc ON mwc.deleted_flg = 0 AND mi.shipment_place_cd = mwc.work_place_cd AND mwc.cal_date = dlvydt
    LEFT OUTER JOIN m_places as mp ON mwc.work_place_cd = mp.place_cd
	LEFT OUTER JOIN m_vat as mv ON msp.vat_div != 2 AND mv.deleted_flg = 0 AND vat_effdate <= dlvydt AND vat_expdate >= dlvydt
	WHERE msp.deleted_flg = 0 AND msp.used_flg = 1 AND msp.effect_date <= dlvydt AND msp.exp_date >= dlvydt AND msp.cust_cd = custcd AND msp.branch_cd = dlvylc AND msp.cust_item_cd = partno ORDER BY CAST(msp.serial_no as decimal) DESC LIMIT 1;
    SELECT FOUND_ROWS() INTO foundrow;
	IF foundrow = 0 THEN
		
		SET logerr = CONCAT('[Sale Price Master] Cannot find price detail in ', partno, ' for customer ', custcd, ' - ', dlvylc, ' at this ', DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m%d'), '%d/%m/%Y'), ' period.');
		CALL InsertLog(logno, 'I', pgmid, pgmnm, 'Sale Price Master', logerr, usrnm, pgmidversion);
	ELSE
		IF @mi_item_cd is null and @mi_item_rev_no is null THEN
			
			SET logerr = CONCAT('[Item Master] Cannot find Item code ', @item_cd, ' Rev. ', @item_rev_no,'.');
			CALL InsertLog(logno, 'I', pgmid, pgmnm, 'Item Master', logerr, usrnm, pgmidversion);
		ELSE
			IF @work_place_cd is null THEN
				
				SET logerr = CONCAT('[Work Calendar Master] Date ', DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m%d'), '%d/%m/%Y'), ' not found in calendar or date is not working day of location ', @shipment_place_cd, ' (Item code ', @item_cd, ' Rev. ', @item_rev_no,').');
				CALL InsertLog(logno, 'I', pgmid, pgmnm, 'Work Calendar Master', logerr, usrnm, pgmidversion);
			ELSE
				IF @holiday_flg = 9 and rmk5 != 3 THEN
					
					SET logerr = CONCAT('[Work Calendar Master] Date ', DATE_FORMAT(STR_TO_DATE(dlvydt, '%Y%m%d'), '%d/%m/%Y'), 'is not working day of location ', @work_place_cd, ' (Item code ', @item_cd, ' Rev. ', @item_rev_no, ').');
					CALL InsertLog(logno, 'I', pgmid, pgmnm, 'Work Calendar Master', logerr, usrnm, pgmidversion);
				ELSE
					IF orderdiv = 3 THEN
						IF ponocnt > 1 THEN 
							
							

								SELECT s_order_no, s_order_br_no, shipment_pre_qtty, original_delivery_date, original_delivery_time, original_s_order_qtty
								, model_cd_s_order, priority_qtty_s_order_unit, mrp_plan_qtty, kd_lot_no INTO rono, robrno, shpqtty, oridlvydt, oridlvytm
								, orisqtty, smodel, priqtty, mrpqtty, kdlotno FROM ro_cont 
								WHERE auto_created_flg = 1 AND split_div = 0 AND division_cd = @division_cd AND factory_cd = @factory_cd 
								AND s_order_div = orderdiv AND cust_cd = custcd AND branch_cd = dlvylc AND cust_item_cd = partno 
								AND cust_order_no = orderno AND original_delivery_date = dlvydt AND original_delivery_time = dlvytm;
								SELECT FOUND_ROWS() INTO checkrow;
						ELSE 	
							IF custcd LIKE 'HATC%' THEN
								SELECT s_order_no, s_order_br_no, shipment_pre_qtty, original_delivery_date, original_delivery_time, original_s_order_qtty
								, model_cd_s_order, priority_qtty_s_order_unit, mrp_plan_qtty, kd_lot_no INTO rono, robrno, shpqtty, oridlvydt, oridlvytm
								, orisqtty, smodel, priqtty, mrpqtty, kdlotno FROM ro_cont 
								WHERE auto_created_flg = 1 AND split_div = 0 AND division_cd = @division_cd AND factory_cd = @factory_cd 
								AND s_order_div = orderdiv AND cust_cd = custcd AND branch_cd = dlvylc AND cust_item_cd = partno 
								AND cust_order_no = orderno; 
								SELECT FOUND_ROWS() INTO checkrow;
							ELSE 
								SELECT s_order_no, s_order_br_no, shipment_pre_qtty, original_delivery_date, original_delivery_time, original_s_order_qtty
								, model_cd_s_order, priority_qtty_s_order_unit, mrp_plan_qtty, kd_lot_no INTO rono, robrno, shpqtty, oridlvydt, oridlvytm
								, orisqtty, smodel, priqtty, mrpqtty, kdlotno FROM ro_cont 
								WHERE auto_created_flg = 1 AND split_div = 0 AND division_cd = @division_cd AND factory_cd = @factory_cd 
								AND s_order_div = orderdiv AND cust_cd = custcd AND branch_cd = dlvylc AND cust_item_cd = partno 
								AND cust_order_no = orderno AND original_delivery_date = dlvydt AND original_delivery_time = dlvytm;
								SELECT FOUND_ROWS() INTO checkrow;
							END IF;
						END IF;
					END IF;
					IF checkrow > 0 THEN
						IF shpqtty = 0 THEN
							IF orisqtty <> forecast or oridlvydt <> dlvydt or oridlvytm <> dlvytm THEN
								UPDATE ro_cont SET 
								cust_serial_no 					= @cust_serial_no,
								billing_cust_cd 				= @billing_cust_cd,
								billing_branch_cd 				= @billing_branch_cd,
								billing_cust_serial_no 			= @billing_cust_serial_no,
								sales_person_cd					= @sales_person_cd,
								item_cust_cd					= @item_cust_cd,
								item_cd							= @item_cd,
								item_rev_no						= @item_rev_no,
								original_delivery_date			= dlvydt,
								original_delivery_time			= dlvytm,
								original_shipment_date			= IF(shpdt=0, @shipment_date, shpdt),
								original_shipment_time			= IF(shptm=0, dlvytm, shptm),
								original_s_order_qtty			= forecast,
								s_order_date					= issdt,
								delivery_date					= dlvydt,
								shift_div						= shiftdiv,
								delivery_time					= dlvytm,
								shipment_date					= IF(shpdt=0, @shipment_date, shpdt),
								shipment_time					= IF(shptm=0, dlvytm, shptm),
								track_no						= truckno,
								customer_delivery_no			= dlvyno,
								s_order_qtty					= @s_order_qtty,
								sales_unit_price				= @sales_unit_price,
								boi_div							= @boi_div,
								vat_cd							= @vat_cd,
								vat_div							= @vat_div,
								vat_included_in_unit_price		= @vat_included_in_unit_price,
								std_unit_cost					= @std_unit_cost,
								s_order_amt						= 0, 
								s_order_amt_without_vat			= 0, 
								vat_amt							= 0, 
								std_cost						= 0, 
								gross_profit					= 0, 
								mrp_remain						= @s_order_qtty,		
								s_order_remain					= @s_order_qtty,
								shipment_pre_remain				= @s_order_qtty, 
								s_order_qtty_s_order_unit		= orderqty,
								s_order_remain_s_order_unit		= orderqty,
								shipment_pre_remain_s_order_unit= orderqty, 
								
								priority_remain_s_order_unit		= (orderqty - priqtty), 
								original_s_order_qtty_s_order_unit	= orderqty, 
                                model_cd						= @model_cd_s_order,
								
								model_cd_s_order				= @model_cd_s_order,
								sales_item_prices_serial_no		= @sales_item_prices_serial_no,
								file_name						= filenm,
								pur_div							= @pur_div,
								shipment_type					= shptyp,
								finished_flg					= 0,
								user_id							= usrnm,
								program_id						= pgmidversion,
								modified_datetime				= now(), 
								order_type						= rmk1, 
								original_shipment_qtty_s_order_unit	= 0, 
								original_s_order_remain_s_order_unit= orderqty, 
								priority_delivery_qtty_s_order_unit = orderqty,
								delivery_location_nm2				= dlvylo2
								WHERE division_cd				= @division_cd
								AND	  factory_cd			= @factory_cd
								AND	  cust_cd				= custcd
								AND	  branch_cd				= dlvylc
								AND   cust_item_cd			= partno
								AND	  cust_order_no		= orderno
								AND	  customer_prod_no	= pdsno
								AND	  s_order_no			= rono
								AND	  s_order_br_no		= robrno
								AND   s_order_div				= orderdiv								
								AND	IF(cust_order_no = '000000000000', original_delivery_date, dlvydt) = dlvydt;
							  							 
								IF kdlotno = '' THEN
										CALL InsertRo(partno, partname, model, custcd, dlvylc, dlvydt, dlvytm, shpdt, shptm, orderno, pdsno, dlvyno, orderqty, forecast, truckno, 
										orderdiv, slipdiv, shiftdiv, issdt, 
										rmk1, rmk2, rmk3, rmk4, rmk5, rmk6, rmk7, rmk8, rmk9, rmk10, robrno, rono, filenm, shptyp, ponocnt, caltyp, usrnm, pgmid, pgmidversion, success, newrono, dlvylo2);
										IF success = 1 THEN										
										SET checkrow = (SELECT IFNULL(COUNT(1), 0) FROM pur_data WHERE s_order_no = CONCAT('RO',rono) AND s_order_br_no = robrno AND po_no IS NOT null);
											IF checkrow = 1 THEN
												SET clpln   = 0;
											ELSE
												SET clpln   = 1;
											END IF;
											
										END IF;
								ELSE
										DELETE FROM ro_cont  WHERE parent_s_order_no = rono AND parent_s_order_br_no = robrno;
										CALL InsertRo(partno, partname, model, custcd, dlvylc, dlvydt, dlvytm, shpdt, shptm, orderno, pdsno, dlvyno, orderqty, forecast, truckno, 
										orderdiv, slipdiv, shiftdiv, issdt, 
										rmk1, rmk2, rmk3, rmk4, rmk5, rmk6, rmk7, rmk8, rmk9, rmk10, robrno, rono, filenm, shptyp, ponocnt, caltyp, usrnm, pgmid, pgmidversion, success, newrono, dlvylo2);
								END IF;						 
							ELSE
								SELECT 1 INTO success;
							END IF;							
							IF (rmk1 != '') or (rmk2 != '') or (rmk3 != '') or (rmk4 != '') or (rmk5 != '') or (rmk6 != '') or (rmk7 != '') or (rmk8 != '') or (rmk9 != '') or (rmk10 != '') or (rmk11 != '') or (rmk12 != '') THEN
								SET checkrow = (SELECT IFNULL(COUNT(1), 0) FROM ro_detail WHERE s_order_no = rono AND s_order_br_no = robrno);
								IF checkrow = 0 THEN
									INSERT ro_detail SET
									s_order_no				= rono,
									s_order_br_no			= robrno,
									ro_detail1				= rmk1,
									ro_detail2				= rmk2,
									ro_detail3				= rmk3,
									ro_detail4				= rmk4,
									ro_detail5				= rmk5,
									ro_detail6				= rmk6,
									ro_detail7				= rmk7,
									ro_detail8				= rmk8,
									ro_detail9				= rmk9,
									ro_detail10				= rmk10,
									ro_detail11				= rmk11,
									ro_detail12				= rmk12,
									ro_detail149			= CONCAT((SELECT header_string FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'RO'), rono),
									ro_detail150			= robrno,
									deleted_flg				= 0,
									user_id					= usrnm,
									program_id				= pgmidversion,
									created_datetime		= now(),
									modified_datetime		= now();
								ELSE
									UPDATE ro_detail SET
									ro_detail1				= rmk1,
									ro_detail2				= rmk2,
									ro_detail3				= rmk3,
									ro_detail4				= rmk4,
									ro_detail5				= rmk5,
									ro_detail6				= rmk6,
									ro_detail7				= rmk7,
									ro_detail8				= rmk8,
									ro_detail9				= rmk9,
									ro_detail10				= rmk10,
									ro_detail11				= rmk11,
									ro_detail12				= rmk12, 
									user_id					= usrnm,
									program_id				= pgmidversion, 
									modified_datetime		= now() 
									WHERE s_order_no		= rono
									AND   s_order_br_no		= robrno;
								END IF;
							END IF;	
						ELSE 
						
						
							SELECT CONCAT(SUBSTRING(custcd, 1, 3), currentNo + 1) INTO rono;
	
							INSERT ro_cont SET 
							s_order_no							= rono,
							s_order_br_no						= robrno,
							division_cd							= @division_cd,
							factory_cd							= @factory_cd,
							s_order_div							= orderdiv,
							slip_div							= slipdiv,
							cust_cd								= custcd,
							branch_cd							= dlvylc,
							cust_serial_no						= @cust_serial_no,
							billing_cust_cd						= @billing_cust_cd,
							billing_branch_cd					= @billing_branch_cd,
							billing_cust_serial_no				= @billing_cust_serial_no,
							sales_person_cd						= @sales_person_cd,
							item_cust_cd						= @item_cust_cd,
							item_cd								= @item_cd,
							item_rev_no							= @item_rev_no,
							original_delivery_date				= dlvydt,
							original_delivery_time				= dlvytm,
							original_shipment_date				= @shipment_date,
							original_shipment_time				= dlvytm,
							cust_order_no						= orderno,
							original_s_order_qtty				= forecast,
							customer_prod_no					= pdsno,
							s_order_date						= issdt,
							delivery_date						= dlvydt,
							shift_div							= shiftdiv,
							delivery_time						= dlvytm,
							shipment_date						= @shipment_date,
							shipment_time						= dlvytm,
							track_no							= truckno,
							customer_delivery_no				= dlvyno,
							delivery_location_nm1				= '',
							s_order_qtty						= @s_order_qtty,
							sales_unit_price					= @sales_unit_price,
							boi_div								= @boi_div,
							vat_cd								= @vat_cd,
							vat_div								= @vat_div,
							vat_included_in_unit_price			= @vat_included_in_unit_price,
							std_unit_cost						= @std_unit_cost,
							s_order_amt							= 0, 
							s_order_amt_without_vat				= 0, 
							vat_amt								= 0, 
							std_cost							= 0, 
							gross_profit						= 0, 
							shipment_qtty						= 0,
							shipment_pre_qtty					= 0, 			
							mrp_remain							= @s_order_qtty,
							s_order_remain						= @s_order_qtty,
							shipment_pre_remain					= @s_order_qtty, 
							s_order_qtty_s_order_unit			= orderqty,
							shipment_qtty_s_order_unit			= 0,
							shipment_pre_qtty_s_order_unit		= 0, 	
							s_order_remain_s_order_unit			= orderqty,
							shipment_pre_remain_s_order_unit	= orderqty, 	
							
							priority_qtty_s_order_unit			= 0, 
							priority_remain_s_order_unit		= orderqty, 
							original_s_order_qtty_s_order_unit	= orderqty, 
							mrp_plan_qtty						= 0, 
							split_div							= 0, 
							parent_s_order_no					= '', 
							parent_s_order_br_no				= 1, 
							priority_div						= 0, 
							priority_delivery_date				= dlvydt, 
							priority_delivery_time				= dlvytm, 
							model_cd							= @model_cd_s_order, 
							
							model_cd_s_order					= @model_cd_s_order,
							cust_item_cd						= partno,
							sales_item_prices_serial_no			= @sales_item_prices_serial_no,
							auto_created_flg					= 1,
							file_name							= filenm,
							pur_div								= @pur_div,
							shipment_type						= shptyp,
							finished_flg						= 0,
							user_id								= usrnm,
							program_id							= pgmidversion,
							created_datetime					= now(),
							order_type							= rmk1, 
							original_shipment_qtty_s_order_unit	= 0, 
							original_s_order_remain_s_order_unit= orderqty, 
							priority_delivery_qtty_s_order_unit = orderqty,
							delivery_location_nm2				= dlvylo2;
							SELECT ROW_COUNT() INTO success;
						
							IF success = 1 THEN
							SET newrono = CONCAT(rono, '-', robrno);
							SET clpln   = 0;
							IF (rmk1 != '') or (rmk2 != '') or (rmk3 != '') or (rmk4 != '') or (rmk5 != '') or (rmk6 != '') or (rmk7 != '') or (rmk8 != '') or (rmk9 != '') or (rmk10 != '') or (rmk11 != '') or (rmk12 != '') THEN
								SET checkrow = (SELECT IFNULL(COUNT(1), 0) FROM ro_detail WHERE s_order_no = rono AND s_order_br_no = robrno);
								IF checkrow = 0 THEN
									INSERT ro_detail SET
									s_order_no				= rono,
									s_order_br_no			= robrno,
									ro_detail1				= rmk1,
									ro_detail2				= rmk2,
									ro_detail3				= rmk3,
									ro_detail4				= rmk4,
									ro_detail5				= rmk5,
									ro_detail6				= rmk6,
									ro_detail7				= rmk7,
									ro_detail8				= rmk8,	
									ro_detail9				= rmk9,
									ro_detail10				= rmk10,
									ro_detail11				= rmk11,
									ro_detail12				= rmk12,
									ro_detail149			= CONCAT((SELECT header_string FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'RO'), rono),
									ro_detail150			= robrno,
									deleted_flg				= 0,
									user_id					= usrnm,
									program_id				= pgmidversion,
									created_datetime		= now(),
									modified_datetime		= now();
								ELSE
									UPDATE ro_detail SET
									ro_detail1				= rmk1,
									ro_detail2				= rmk2,
									ro_detail3				= rmk3,
									ro_detail4				= rmk4,
									ro_detail5				= rmk5,
									ro_detail6				= rmk6,
									ro_detail7				= rmk7,
									ro_detail8				= rmk8,
									ro_detail9				= rmk9,
									ro_detail10				= rmk10,
									ro_detail11				= rmk11,
									ro_detail12				= rmk12, 
									user_id					= usrnm, 
									program_id				= pgmidversion, 
									modified_datetime		= now() 
									WHERE s_order_no		= rono
									AND   s_order_br_no		= robrno;
								END IF;
							END IF;
						END IF;						
						SELECT 1 INTO success;
							
								
								
									
									
									
									
									
									
									
									
									
									
									
									
									
									
									
									
									
									
									
									
								
									
									
									
									
									
									
									
									
									
									
									
									
									
									
									
									
									
									
								
							
							
						END IF;
					ELSE

						SELECT CONCAT(SUBSTRING(custcd, 1, 3), currentNo + 1) INTO rono;

						INSERT ro_cont SET 
						s_order_no							= rono,
						s_order_br_no						= robrno,
						division_cd							= @division_cd,
						factory_cd							= @factory_cd,
						s_order_div							= orderdiv,
						slip_div							= slipdiv,
						cust_cd								= custcd,
						branch_cd							= dlvylc,
						cust_serial_no						= @cust_serial_no,
						billing_cust_cd						= @billing_cust_cd,
						billing_branch_cd					= @billing_branch_cd,
						billing_cust_serial_no				= @billing_cust_serial_no,
						sales_person_cd						= @sales_person_cd,
						item_cust_cd						= @item_cust_cd,
						item_cd								= @item_cd,
						item_rev_no							= @item_rev_no,
						original_delivery_date				= dlvydt,
						original_delivery_time				= dlvytm,
						original_shipment_date				= @shipment_date,
						original_shipment_time				= dlvytm,
						cust_order_no						= orderno,
						original_s_order_qtty				= forecast,
						customer_prod_no					= pdsno,
						s_order_date						= issdt,
						delivery_date						= dlvydt,
						shift_div							= shiftdiv,
						delivery_time						= dlvytm,
						shipment_date						= @shipment_date,
						shipment_time						= dlvytm,
						track_no							= truckno,
						customer_delivery_no				= dlvyno,
						delivery_location_nm1				= '',
						s_order_qtty						= @s_order_qtty,
						sales_unit_price					= @sales_unit_price,
						boi_div								= @boi_div,
						vat_cd								= @vat_cd,
						vat_div								= @vat_div,
						vat_included_in_unit_price			= @vat_included_in_unit_price,
						std_unit_cost						= @std_unit_cost,
						s_order_amt							= 0, 
						s_order_amt_without_vat				= 0, 
						vat_amt								= 0, 
						std_cost							= 0, 
						gross_profit						= 0, 
						shipment_qtty						= 0,
						shipment_pre_qtty					= 0, 			
						mrp_remain							= @s_order_qtty,
						s_order_remain						= @s_order_qtty,
						shipment_pre_remain					= @s_order_qtty, 
						s_order_qtty_s_order_unit			= orderqty,
						shipment_qtty_s_order_unit			= 0,
						shipment_pre_qtty_s_order_unit		= 0, 	
						s_order_remain_s_order_unit			= orderqty,
						shipment_pre_remain_s_order_unit	= orderqty, 	
						
						priority_qtty_s_order_unit			= 0, 
						priority_remain_s_order_unit		= orderqty, 
						original_s_order_qtty_s_order_unit	= orderqty, 
						mrp_plan_qtty						= 0, 
						split_div							= 0, 
						parent_s_order_no					= '', 
						parent_s_order_br_no				= 1, 
						priority_div						= 0, 
						priority_delivery_date				= dlvydt, 
						priority_delivery_time				= dlvytm, 
						model_cd							= @model_cd_s_order, 
						
						model_cd_s_order					= @model_cd_s_order,
						cust_item_cd						= partno,
						sales_item_prices_serial_no			= @sales_item_prices_serial_no,
						auto_created_flg					= 1,
						file_name							= filenm,
						pur_div								= @pur_div,
						shipment_type						= shptyp,
						finished_flg						= 0,
						user_id								= usrnm,
						program_id							= pgmidversion,
						created_datetime					= now(),
						order_type							= rmk1, 
						original_shipment_qtty_s_order_unit	= 0, 
						original_s_order_remain_s_order_unit= orderqty, 
						priority_delivery_qtty_s_order_unit = orderqty,
						delivery_location_nm2				= dlvylo2;
						SELECT ROW_COUNT() INTO success;
						IF success = 1 THEN
							SET newrono = CONCAT(rono, '-', robrno);
							SET clpln   = 0;
							IF (rmk1 != '') or (rmk2 != '') or (rmk3 != '') or (rmk4 != '') or (rmk5 != '') or (rmk6 != '') or (rmk7 != '') or (rmk8 != '') or (rmk9 != '') or (rmk10 != '') or (rmk11 != '') or (rmk12 != '') THEN
								SET checkrow = (SELECT IFNULL(COUNT(1), 0) FROM ro_detail WHERE s_order_no = rono AND s_order_br_no = robrno);
								IF checkrow = 0 THEN
									INSERT ro_detail SET
									s_order_no				= rono,
									s_order_br_no			= robrno,
									ro_detail1				= rmk1,
									ro_detail2				= rmk2,
									ro_detail3				= rmk3,
									ro_detail4				= rmk4,
									ro_detail5				= rmk5,
									ro_detail6				= rmk6,
									ro_detail7				= rmk7,
									ro_detail8				= rmk8,	
									ro_detail9				= rmk9,
									ro_detail10				= rmk10,
									ro_detail11				= rmk11,
									ro_detail12				= rmk12,
									ro_detail149			= CONCAT((SELECT header_string FROM m_numbers WHERE deleted_flg = 0 AND report_cd = 'RO'), rono),
									ro_detail150			= robrno,
									deleted_flg				= 0,
									user_id					= usrnm,
									program_id				= pgmidversion,
									created_datetime		= now(),
									modified_datetime		= now();
								ELSE
									UPDATE ro_detail SET
									ro_detail1				= rmk1,
									ro_detail2				= rmk2,
									ro_detail3				= rmk3,
									ro_detail4				= rmk4,
									ro_detail5				= rmk5,
									ro_detail6				= rmk6,
									ro_detail7				= rmk7,
									ro_detail8				= rmk8,
									ro_detail9				= rmk9,
									ro_detail10				= rmk10,
									ro_detail11				= rmk11,
									ro_detail12				= rmk12, 
									user_id					= usrnm, 
									program_id				= pgmidversion, 
									modified_datetime		= now() 
									WHERE s_order_no		= rono
									AND   s_order_br_no		= robrno;
								END IF;
							END IF;
						END IF;
					END IF;
				END IF;
			END IF;
		END IF;
	END IF;
    IF success = 1 THEN
		
		SET logerr = CONCAT('[success] ', 'rono=', rono, ', partno=', partno, ', po=', orderno, ', itemcd=', @item_cd);
		CALL InsertLog(logno, 'I-PGM', pgmid, pgmnm, pgmnm, logerr, usrnm, pgmidversion);


      SET currentNo = currentNo + 1;
	
	END IF;
END;

