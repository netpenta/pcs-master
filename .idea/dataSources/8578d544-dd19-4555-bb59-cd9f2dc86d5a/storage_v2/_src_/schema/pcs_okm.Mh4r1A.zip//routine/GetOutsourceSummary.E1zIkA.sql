create
    definer = root@localhost procedure GetOutsourceSummary(IN in_outside_flg int, IN in_dodate_from int,
                                                           IN in_dodate_to int, IN in_factory_cd varchar(50),
                                                           IN in_item_cust_cd varchar(50), IN in_item_cd varchar(50),
                                                           IN in_item_revno varchar(50), IN in_workplace_cd varchar(50),
                                                           IN in_status_div int, IN in_pagerow int, IN in_pagesize int)
BEGIN

SELECT  plan.parent_item_cd, plan.summ_index, plan.summ_type, plan.item_cust_cd, plan.item_cd, plan.item_rev_no, IFNULL(good_stock_qtty,0) as prev_good_stock_qtty,

        @balance_qtty:= IF(summ_index =1, IFNULL(good_stock_qtty,0) + IFNULL(prod_prev_qtty,0), @balance_qtty - IFNULL(used_prev_qtty,0)) as good_stock_qtty,

        IFNULL(IF(summ_index = 1, prod_prev_qtty , used_prev_qtty), 0) as summ_prev_qtty,

        IFNULL(IF(summ_index = 1, prod_total_qtty, used_total_qtty), 0) as summ_total_qtty,

        IFNULL(IF(summ_index = 1, prod_next_qtty , used_next_qtty), 0) as summ_next_qtty,

        IFNULL(IF(summ_index = 1, prod_summ_date , used_summ_date), 0) as summ_data_date,

        IFNULL(IF(summ_index = 1, prod_summ_qtty , used_summ_qtty), 0) as summ_data_qtty,

        IFNULL(IF(summ_index = 1, prod_summ_data , used_summ_data), 0) as summ_data

FROM(

	  SELECT DISTINCT plan.parent_item_cd, summ_index, plan.level, summ_type, plan.item_cust_cd, plan.item_cd, plan.item_rev_no, good_stock_qtty FROM pl_sched_detail as plan

     CROSS JOIN(SELECT 1 as summ_index, 'PROD' as summ_type UNION SELECT 2 as summ_index, 'USE' as summ_type ) as typeofdata

     LEFT OUTER JOIN m_item_procs as proc ON proc.item_cust_cd = plan.item_cust_cd AND proc.item_cd = plan.item_cd AND proc.item_rev_no = plan.item_rev_no AND proc.line_no = plan.item_proc_line_no

     LEFT JOIN (

		   SELECT item_cust_cd, item_cd, item_rev_no, SUM(good_stock_qtty) as good_stock_qtty  FROM st_item WHERE  stock_yyyymm = 999999

		   GROUP  BY item_cust_cd, item_cd, item_rev_no HAVING SUM(good_stock_qtty) > 0

	  )as  stock ON stock.item_cust_cd = plan.item_cust_cd AND  stock.item_cd = plan.item_cd AND stock.item_rev_no = plan.item_rev_no

     WHERE  plan_prod_date >= in_dodate_from AND plan_prod_date <= in_dodate_to AND proc_div <> 4 AND plan.finished_flg = 0 AND plan.item_rev_no <> '0_MOVE'

     AND    plan.outside_flg = 1

	  AND    plan.factory_cd = CASE WHEN LENGTH(in_factory_cd) > 0 THEN in_factory_cd ELSE plan.factory_cd END

	  AND    plan.item_cust_cd LIKE CASE WHEN LENGTH(in_item_cust_cd) > 0 THEN in_item_cust_cd ELSE '%%' END

     AND    plan.item_cd LIKE CASE WHEN LENGTH(in_item_cd) > 0 THEN in_item_cd ELSE '%%' END

     AND    plan.item_rev_no LIKE CASE WHEN LENGTH(in_item_revno) > 0 THEN in_item_revno ELSE '%%' END 

     AND    plan.work_place_cd LIKE CASE WHEN LENGTH(in_workplace_cd) > 0 THEN in_workplace_cd ELSE '%%' END

	  ORDER BY plan.parent_item_cd, summ_index, plan.level LIMIT in_pagerow, in_pagesize	  

)as plan JOIN (SELECT @balance_qtty:=0) AS define_variable

LEFT JOIN (

	  SELECT 1 as summ_index, item_cust_cd, item_cd, item_rev_no, SUM(prod_prev_qtty) as prod_prev_qtty, SUM(request_remain) as prod_total_qtty, SUM(prod_next_qtty) as prod_next_qtty,

            GROUP_CONCAT(IF(plan_prod_date >= in_dodate_from AND plan_prod_date <= in_dodate_to, plan_prod_date , null) ORDER BY plan_prod_date) as prod_summ_date,

            GROUP_CONCAT(IF(plan_prod_date >= in_dodate_from AND plan_prod_date <= in_dodate_to, request_remain , null) ORDER BY plan_prod_date) as prod_summ_qtty,

            GROUP_CONCAT(IF(plan_prod_date >= in_dodate_from AND plan_prod_date <= in_dodate_to, CONCAT(request_remain,'/',request_qtty_struct_unit) , null) ORDER BY plan_prod_date) as prod_summ_data

     FROM(

			SELECT   plan_prod_date, detail.item_cust_cd, detail.item_cd, detail.item_rev_no,

					 IF(detail.plan_prod_date <  in_dodate_from, SUM(request_remain_struct_unit), 0) as prod_prev_qtty,

					 IF(detail.plan_prod_date >= in_dodate_from AND plan_prod_date <= in_dodate_to, SUM(request_remain_struct_unit), 0) as request_remain,

					 IF(detail.plan_prod_date >= in_dodate_from AND plan_prod_date <= in_dodate_to, SUM(request_qtty_struct_unit)  , 0) as request_qtty_struct_unit,

					 IF(plan_prod_date >  in_dodate_to  , SUM(request_remain_struct_unit), 0) as prod_next_qtty

			FROM     pl_sched_detail as detail

			LEFT OUTER JOIN m_item_procs as proc ON proc.item_cust_cd = detail.item_cust_cd AND proc.item_cd = detail.item_cd AND proc.item_rev_no = detail.item_rev_no AND proc.line_no = detail.item_proc_line_no

         WHERE    plan_prod_date >= (SELECT this_month_start_date FROM m_sys_admin ORDER BY this_month_start_date DESC LIMIT 1) AND plan_prod_date <= CAST(DATE_FORMAT(DATE_ADD(STR_TO_DATE(in_dodate_to,'%Y%m%d'), interval 7 day),'%Y%m%d') as Decimal) AND finished_flg = 0

	      AND      factory_cd = CASE WHEN LENGTH(in_factory_cd) > 0 THEN in_factory_cd ELSE factory_cd END

	      AND      detail.item_cust_cd LIKE CASE WHEN LENGTH(in_item_cust_cd) > 0 THEN in_item_cust_cd ELSE '%%' END

         AND      detail.item_cd LIKE CASE WHEN LENGTH(in_item_cd) > 0 THEN in_item_cd ELSE '%%' END

         AND      detail.item_rev_no LIKE CASE WHEN LENGTH(in_item_revno) > 0 THEN in_item_revno ELSE '%%' END

         AND      work_place_cd LIKE CASE WHEN LENGTH(in_workplace_cd) > 0 THEN in_workplace_cd ELSE '%%' END

         AND      outside_flg = 1  AND proc_div <> 4

         GROUP BY plan_prod_date, detail.item_cust_cd, detail.item_cd, detail.item_rev_no

     )as plandetail GROUP BY item_cust_cd, item_cd, item_rev_no

)as prod USING(summ_index, item_cust_cd, item_cd, item_rev_no)

LEFT JOIN (

	  SELECT 2 as summ_index, item_cust_cd, item_cd, item_rev_no, SUM(used_prev_qtty) as used_prev_qtty, SUM(request_remain) as used_total_qtty, SUM(used_next_qtty) as used_next_qtty,

            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, plan_delivery_date, null) ORDER BY plan_delivery_date) as used_summ_date,

            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, request_remain , null) ORDER BY plan_delivery_date) as used_summ_qtty,

            GROUP_CONCAT(IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, CONCAT(request_remain,'/',request_qtty_struct_unit) , null) ORDER BY plan_delivery_date) as used_summ_data

     FROM(

			SELECT    plan_delivery_date, item_cust_cd, item_cd, item_rev_no,

					  IF(plan_delivery_date  < in_dodate_from, SUM(request_remain_struct_unit), 0) as used_prev_qtty,

					  IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, SUM(request_remain_struct_unit), 0) as request_remain,

					  IF(plan_delivery_date >= in_dodate_from AND plan_delivery_date <= in_dodate_to, SUM(request_qtty_struct_unit), 0) as request_qtty_struct_unit,

					  IF(plan_delivery_date > in_dodate_to  , SUM(request_remain_struct_unit), 0) as used_next_qtty

			FROM      pl_sched_detail as detail







           WHERE     plan_delivery_date >= (SELECT this_month_start_date FROM m_sys_admin ORDER BY this_month_start_date DESC LIMIT 1) AND plan_delivery_date <= CAST(DATE_FORMAT(DATE_ADD(STR_TO_DATE(in_dodate_to,'%Y%m%d'), interval 7 day),'%Y%m%d') as Decimal) AND expand_div > 0 AND finished_flg = 0

	        AND       factory_cd = CASE WHEN LENGTH(in_factory_cd) > 0 THEN in_factory_cd ELSE factory_cd END

	        AND       item_cust_cd LIKE CASE WHEN LENGTH(in_item_cust_cd) > 0 THEN in_item_cust_cd ELSE '%%' END

           AND       item_cd LIKE CASE WHEN LENGTH(in_item_cd) > 0 THEN in_item_cd ELSE '%%' END

           AND       item_rev_no LIKE CASE WHEN LENGTH(in_item_revno) > 0 THEN in_item_revno ELSE '%%' END

           AND       work_place_cd LIKE CASE WHEN LENGTH(in_workplace_cd) > 0 THEN in_workplace_cd ELSE '%%' END



           GROUP BY  plan_delivery_date, item_cust_cd, item_cd, item_rev_no

     )as plandetail GROUP BY item_cust_cd, item_cd, item_rev_no

)as used USING(summ_index, item_cust_cd, item_cd, item_rev_no)  ORDER BY parent_item_cd, item_rev_no ASC, summ_index;





END;

