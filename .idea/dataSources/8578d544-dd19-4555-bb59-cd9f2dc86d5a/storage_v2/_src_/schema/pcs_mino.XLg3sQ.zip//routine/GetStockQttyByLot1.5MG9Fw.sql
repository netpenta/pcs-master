create
    definer = penta@localhost function GetStockQttyByLot1(param_stock_yyyymm int, param_inout_date_to int,
                                                          param_item_cust_cd varchar(50), param_item_cd varchar(250),
                                                          param_item_rev_no varchar(50), param_proc_cd varchar(50),
                                                          param_place_cd varchar(50),
                                                          param_lot_no varchar(50)) returns json
BEGIN
   DECLARE var_this_month_start_date INT;
   DECLARE var_first_good_stock_qtty DECIMAL(13,3);
   DECLARE var_first_ng_stock_qtty   DECIMAL(13,3);
   DECLARE var_good_stock_qtty DECIMAL(13,3);
   DECLARE var_good_stock_struct_unit_qtty DECIMAL(13,3);
   DECLARE var_ng_stock_qtty DECIMAL(13,3); 
   DECLARE var_struct_rate DECIMAL(13,3); 
	SET var_struct_rate = IFNULL((SELECT struct_rate FROM m_items WHERE item_cust_cd = param_item_cust_cd AND item_cd = param_item_cd AND item_rev_no = param_item_rev_no), 0);
	SET var_this_month_start_date = IFNULL((SELECT this_month_start_date FROM st_lot WHERE item_cust_cd = param_item_cust_cd AND item_cd = param_item_cd AND item_rev_no = param_item_rev_no AND proc_cd = param_proc_cd AND work_place_cd = param_place_cd AND lot_no = param_lot_no AND stock_yyyymm <= IF(param_stock_yyyymm >= (SELECT this_month FROM m_sys_admin), 999999, param_stock_yyyymm) ORDER BY stock_yyyymm DESC LIMIT 1), 0);
	SET var_first_good_stock_qtty = IFNULL((SELECT first_good_stock_qtty FROM st_lot WHERE item_cust_cd = param_item_cust_cd AND item_cd = param_item_cd AND item_rev_no = param_item_rev_no AND proc_cd = param_proc_cd AND work_place_cd = param_place_cd AND lot_no = param_lot_no AND stock_yyyymm <= IF(param_stock_yyyymm >= (SELECT this_month FROM m_sys_admin), 999999, param_stock_yyyymm) ORDER BY stock_yyyymm DESC LIMIT 1), 0.000);
	SET var_good_stock_qtty = var_first_good_stock_qtty + IFNULL((
		SELECT   SUM((CASE WHEN inout_div in (11,21,22) THEN inout_qtty  WHEN inout_div in (81) and inout_qtty >= 0 THEN inout_qtty ELSE 0 END)) 
             - SUM((CASE WHEN inout_div in (41,51,52) THEN inout_qtty  WHEN inout_div in (12,42) THEN inout_qtty * -1 WHEN inout_div in (81) and inout_qtty < 0 THEN inout_qtty * -1 ELSE 0 END)) 
             - SUM((CASE WHEN inout_div IN (55) THEN inout_qtty ELSE 0 END))
	   FROM st_lot_inout 
	   WHERE inout_date >= var_this_month_start_date AND inout_date <= param_inout_date_to AND lot_no = param_lot_no
	   AND   item_cust_cd = param_item_cust_cd AND item_cd = param_item_cd AND item_rev_no = param_item_rev_no AND proc_cd = param_proc_cd AND place_cd = param_place_cd
      GROUP BY place_cd, proc_cd, item_cust_cd, item_cd, item_rev_no, lot_no
	), 0.000);
	
	SET var_first_ng_stock_qtty = IFNULL((SELECT first_ng_stock_qtty FROM st_lot WHERE item_cust_cd = param_item_cust_cd AND item_cd = param_item_cd AND item_rev_no = param_item_rev_no AND proc_cd = param_proc_cd AND work_place_cd = param_place_cd AND lot_no = param_lot_no AND stock_yyyymm <= IF(param_stock_yyyymm >= (SELECT this_month FROM m_sys_admin), 999999, param_stock_yyyymm) ORDER BY stock_yyyymm DESC LIMIT 1), 0.000);
	SET var_ng_stock_qtty = var_first_ng_stock_qtty + IFNULL((
		SELECT   SUM((CASE WHEN inout_div in (82) THEN inout_qtty ELSE 0 END)) 
             - SUM((CASE WHEN inout_div in (12,42) THEN inout_qtty * -1 WHEN inout_div in (81) and inout_qtty < 0 THEN inout_qtty * -1 ELSE 0 END)) 
             - SUM((CASE WHEN inout_div IN (55) THEN inout_qtty ELSE 0 END))
	   FROM st_lot_inout 
	   WHERE inout_date >= var_this_month_start_date AND inout_date <= param_inout_date_to AND lot_no = param_lot_no
	   AND   item_cust_cd = param_item_cust_cd AND item_cd = param_item_cd AND item_rev_no = param_item_rev_no AND proc_cd = param_proc_cd AND place_cd = param_place_cd
      GROUP BY place_cd, proc_cd, item_cust_cd, item_cd, item_rev_no, lot_no
	), 0.000);
	
	SET var_good_stock_struct_unit_qtty = var_good_stock_qtty * var_struct_rate;
	RETURN JSON_OBJECT('this_month_start_date', var_this_month_start_date, 'inout_date_to', param_inout_date_to, 'lot_no', param_lot_no, 'first_good_stock_qtty', var_first_good_stock_qtty, 'good_stock_qtty', var_good_stock_qtty, 'good_stock_struct_unit_qtty', var_good_stock_struct_unit_qtty,
	                   'first_ng_stock_qtty'  , var_first_ng_stock_qtty, 'ng_good_stock_qtty', var_ng_stock_qtty);
END;

