create
    definer = penta@localhost function get_next_p_result_br_no(param_tag_no varchar(50), param_tag_rev_no int,
                                                               param_p_order_no varchar(50), param_p_order_br_no int,
                                                               param_lot_no varchar(50),
                                                               param_lot_br_no int) returns int
BEGIN
   DECLARE next_p_result_br_no INT;
	SET next_p_result_br_no = (SELECT IFNULL(MAX(p_result_br_no), 0) + 1 FROM pur_tag_result WHERE tag_no = param_tag_no AND tag_rev_no = param_tag_rev_no AND p_order_no = param_p_order_no AND p_order_br_no = param_p_order_br_no AND lot_no = param_lot_no AND lot_br_no = param_lot_br_no);
	RETURN next_p_result_br_no;
END;

