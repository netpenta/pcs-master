create
    definer = penta@localhost function GetGoodStockQttyByItem(param_stock_yyyymm int, param_date_from int,
                                                              param_date_to int, param_item_cust_cd varchar(50),
                                                              param_item_cd varchar(50), param_item_rev_no varchar(50),
                                                              param_proc_cd varchar(50),
                                                              param_stock_place_cd varchar(50),
                                                              param_stock_type varchar(50)) returns decimal(13, 3)
BEGIN
    DECLARE stock_qtty        decimal(13,3) default 0.000;  
    DECLARE first_stock_qtty  decimal(13,3) default 0.000;  
    DECLARE stock_in_qtty     decimal(13,3) default 0.000;  
    DECLARE stock_out_qtty    decimal(13,3) default 0.000;  
    DECLARE scrap_qtty        decimal(13,3) default 0.000;
    DECLARE month_start_date  decimal(8,0)  default 0.000;
    DECLARE yyyymm            decimal(6,0)  default 0.000;
     
    SET yyyymm           = IFNULL((SELECT stock_yyyymm          FROM st_item WHERE item_cd = param_item_cd AND item_cust_cd = param_item_cust_cd AND item_rev_no = param_item_rev_no AND work_place_cd = param_stock_place_cd AND proc_cd = param_proc_cd AND stock_yyyymm = param_stock_yyyymm), 999999);
    SET month_start_date = (SELECT this_month_start_date FROM st_item WHERE item_cd = param_item_cd AND item_cust_cd = param_item_cust_cd AND item_rev_no = param_item_rev_no AND work_place_cd = param_stock_place_cd AND proc_cd = param_proc_cd AND stock_yyyymm = yyyymm);
     
    SET first_stock_qtty  = (
        SELECT first_good_stock_qtty FROM st_item WHERE item_cd = param_item_cd AND item_cust_cd = param_item_cust_cd AND item_rev_no = param_item_rev_no
        AND    work_place_cd = param_stock_place_cd AND proc_cd = param_proc_cd 
        AND    stock_yyyymm = IF(yyyymm = 999999, IF(param_date_from >= month_start_date, 999999, param_stock_yyyymm), yyyymm)
     ); 
      
    SET stock_in_qtty     = (
        SELECT SUM(CASE WHEN inout_div IN (11,21,23) THEN inout_qtty WHEN inout_div IN (81) AND inout_qtty >= 0 THEN inout_qtty ELSE 0 END) as good_stock_in_qtty
        FROM st_lot_inout as lot 
        WHERE lot.inout_date  >= month_start_date AND lot.inout_date < param_date_from
        AND   lot.item_cust_cd = param_item_cust_cd AND lot.item_cd     = param_item_cd AND lot.item_rev_no = param_item_rev_no
        AND   lot.proc_cd      = param_proc_cd      AND lot.place_cd    = param_stock_place_cd
    );
     
    SET stock_out_qtty     = (
        SELECT SUM(CASE WHEN inout_div IN (41,51,53) THEN inout_qtty WHEN inout_div IN (12,42) THEN inout_qtty * -1 WHEN inout_div IN (81) AND inout_qtty < 0 THEN inout_qtty * -1 ELSE 0 END)
        FROM st_lot_inout as lot 
        WHERE lot.inout_date  >= month_start_date   AND lot.inout_date < param_date_from
        AND   lot.item_cust_cd = param_item_cust_cd AND lot.item_cd     = param_item_cd AND lot.item_rev_no = param_item_rev_no
        AND   lot.proc_cd      = param_proc_cd      AND lot.place_cd    = param_stock_place_cd
    );
     
    SET scrap_qtty        = (
        SELECT SUM(CASE WHEN inout_div IN (55) THEN inout_qtty ELSE 0 END)
        FROM  st_lot_inout as lot 
        WHERE lot.inout_date  >= month_start_date   AND lot.inout_date < param_date_from
        AND   lot.item_cust_cd = param_item_cust_cd AND lot.item_cd     = param_item_cd AND lot.item_rev_no = param_item_rev_no
        AND   lot.proc_cd      = param_proc_cd      AND lot.place_cd    = param_stock_place_cd
    );
     
    IF param_stock_type = 'FIRST_GOOD_STOCK_QTTY' THEN SET stock_qtty = first_stock_qtty; END IF;
    IF param_stock_type = 'GOOD_STOCK_IN_QTTY'    THEN SET stock_qtty = stock_in_qtty;    END IF;
    IF param_stock_type = 'GOOD_STOCK_OUT_QTTY'   THEN SET stock_qtty = stock_out_qtty;   END IF;
    IF param_stock_type = 'SCRAP_STOCK_QTTY'      THEN SET stock_qtty = scrap_qtty;       END IF;
    IF param_stock_type = 'GOOD_STOCK_QTTY'       THEN SET stock_qtty = IFNULL(first_stock_qtty,0) + IFNULL(stock_in_qtty,0) - IFNULL(stock_out_qtty,0) - IFNULL(scrap_qtty,0);  END IF;
    return stock_qtty;
END;

