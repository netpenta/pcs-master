create
    definer = penta@localhost function get_next_result_br_no(param_tag_no varchar(50), param_tag_rev_no int,
                                                             param_pf_wo_no varchar(50), param_pf_wo_br_no int,
                                                             param_lot_no varchar(50), param_lot_br_no int) returns int
BEGIN
   DECLARE next_result_br_no INT;
	SET next_result_br_no = (SELECT IFNULL(MAX(result_br_no), 0) + 1 FROM pr_tag_result WHERE tag_no = param_tag_no AND tag_rev_no = param_tag_rev_no AND pf_wo_no = param_pf_wo_no AND pf_wo_br_no = param_pf_wo_br_no AND lot_no = param_lot_no AND lot_br_no = param_lot_br_no);
	RETURN next_result_br_no;
END;

