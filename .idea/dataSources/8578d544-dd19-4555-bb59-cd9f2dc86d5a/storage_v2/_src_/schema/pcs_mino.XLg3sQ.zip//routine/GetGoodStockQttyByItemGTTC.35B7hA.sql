create
    definer = penta@localhost function GetGoodStockQttyByItemGTTC(param_stock_yyyymm int, param_date_from int,
                                                                  param_date_to int, param_item_cust_cd varchar(50),
                                                                  param_item_cd varchar(50),
                                                                  param_item_rev_no varchar(50),
                                                                  param_stock_place_cd varchar(50),
                                                                  param_proc_cd varchar(50),
                                                                  param_stock_type varchar(50)) returns text
BEGIN
	 DECLARE stock_qtty        decimal(13,3) default 0.000;  
	 DECLARE good_stock_qtty   decimal(13,3) default 0.000; 
	 DECLARE prev_stock_qtty   decimal(13,3) default 0.000; 	 
    DECLARE first_stock_qtty  decimal(13,3) default 0.000;  
    DECLARE stock_in_qtty     decimal(13,3) default 0.000;  
    DECLARE stock_out_qtty    decimal(13,3) default 0.000;  
    DECLARE scrap_qtty        decimal(13,3) default 0.000;
    DECLARE month_start_date  decimal(8,0)  default 0;
    DECLARE next_7_date       decimal(8,0)  default 0;
    DECLARE yyyymm            decimal(6,0)  default 0;
    DECLARE prev_plan_prod_qtty     decimal(13,3) default 0.000;
    DECLARE prev_plan_use_qtty      decimal(13,3) default 0.000;
    DECLARE prev_plan_shipment_qtty decimal(13,3) default 0.000;
    DECLARE next_plan_prod_qtty     decimal(13,3) default 0.000;
    DECLARE next_plan_use_qtty      decimal(13,3) default 0.000;
    DECLARE next_plan_shipment_qtty decimal(13,3) default 0.000;
    DECLARE outsource decimal(1,0)  default 0;
    
	 SET outsource =  (SELECT IFNULL(COUNT(1),0) FROM m_procs WHERE proc_cd = param_proc_cd AND proc_div NOT IN (4,5,6));
    
    #SET yyyymm           = IFNULL((SELECT stock_yyyymm          FROM st_item WHERE item_cd = param_item_cd AND item_cust_cd = param_item_cust_cd AND item_rev_no = param_item_rev_no AND work_place_cd = param_stock_place_cd AND proc_cd = param_proc_cd AND stock_yyyymm = param_stock_yyyymm), 999999);
    SET yyyymm = (
	     SELECT stock_yyyymm FROM st_item 
		  WHERE  item_cd       = param_item_cd        AND item_cust_cd = param_item_cust_cd AND item_rev_no = param_item_rev_no
        AND    work_place_cd = param_stock_place_cd AND proc_cd      = param_proc_cd      AND this_month_start_date <= param_date_from 
		  ORDER BY this_month_start_date DESC LIMIT 1
	 );
	 
	 SET month_start_date = (
	     SELECT this_month_start_date FROM st_item 
		  WHERE  item_cd       = param_item_cd        AND item_cust_cd = param_item_cust_cd AND item_rev_no = param_item_rev_no
        AND    work_place_cd = param_stock_place_cd AND proc_cd      = param_proc_cd      AND stock_yyyymm= yyyymm 		 
	 );
	 
    SET month_start_date  = IF(IFNULL(month_start_date,0) = 0, (SELECT CAST(DATE_FORMAT(DATE_SUB(STR_TO_DATE(param_date_from, '%Y%m%d'), INTERVAL DAYOFMONTH(STR_TO_DATE(param_date_from, '%Y%m%d'))-1 DAY), '%Y%m%d') as Decimal(8,0))), month_start_date);
    SET next_7_date       = (SELECT CAST(DATE_FORMAT(DATE_ADD(STR_TO_DATE(param_date_from, '%Y%m%d'), INTERVAL 7 DAY), '%Y%m%d') as Decimal(8,0)));
    
    SET first_stock_qtty  = (
		  SELECT first_good_stock_qtty FROM st_item WHERE item_cd = param_item_cd AND item_cust_cd = param_item_cust_cd AND item_rev_no = param_item_rev_no
        AND    work_place_cd = param_stock_place_cd AND proc_cd = param_proc_cd 
        AND    stock_yyyymm = IFNULL(yyyymm,999999)
     ); 
     
	SET stock_in_qtty     = (
		  SELECT SUM(CASE WHEN inout_div IN (11,21,23) THEN inout_qtty WHEN inout_div IN (81) AND inout_qtty >= 0 THEN inout_qtty ELSE 0 END) as good_stock_in_qtty
		  FROM st_lot_inout as lot 
		  WHERE lot.inout_date  >= (SELECT this_month_start_date FROM m_sys_admin)   AND lot.inout_date < param_date_from
		  AND   lot.item_cust_cd = param_item_cust_cd AND lot.item_cd     = param_item_cd AND lot.item_rev_no = param_item_rev_no
		  AND   lot.proc_cd      = param_proc_cd      AND lot.place_cd    = param_stock_place_cd
    );
    
    SET stock_out_qtty     = (
		  SELECT SUM(CASE WHEN inout_div IN (41,51,53) THEN inout_qtty WHEN inout_div IN (12,42) THEN inout_qtty * -1 WHEN inout_div IN (81) AND inout_qtty < 0 THEN inout_qtty * -1 ELSE 0 END)
		  FROM st_lot_inout as lot 
		  WHERE lot.inout_date  >= (SELECT this_month_start_date FROM m_sys_admin)   AND lot.inout_date < param_date_from
		  AND   lot.item_cust_cd = param_item_cust_cd AND lot.item_cd     = param_item_cd AND lot.item_rev_no = param_item_rev_no
		  AND   lot.proc_cd      = param_proc_cd      AND lot.place_cd    = param_stock_place_cd
    );
    
    SET scrap_qtty        = (
		  SELECT SUM(CASE WHEN inout_div IN (55) THEN inout_qtty ELSE 0 END)
		  FROM  st_lot_inout as lot 
		  WHERE lot.inout_date  >= (SELECT this_month_start_date FROM m_sys_admin)   AND lot.inout_date < param_date_from
		  AND   lot.item_cust_cd = param_item_cust_cd AND lot.item_cd     = param_item_cd AND lot.item_rev_no = param_item_rev_no
		  AND   lot.proc_cd      = param_proc_cd      AND lot.place_cd    = param_stock_place_cd
    );
    
    IF (outsource = 0) THEN
	    SET prev_plan_prod_qtty     = (
		     SELECT SUM(request_remain_struct_unit) FROM pl_sched_detail 
			  WHERE plan_prod_date  >= (SELECT this_month_start_date FROM m_sys_admin)   AND plan_prod_date < param_date_from
			  AND   item_cust_cd     = param_item_cust_cd AND item_cd        = param_item_cd AND item_rev_no = param_item_rev_no 
			  AND   finished_flg     = 0 AND expand_div = 0
		 );
		 
		 SET prev_plan_use_qtty      = (	 
			 SELECT SUM(request_remain_struct_unit)  FROM pl_sched_detail 
			 WHERE  plan_delivery_date >= (SELECT this_month_start_date FROM m_sys_admin)   AND plan_delivery_date < param_date_from
			 AND    item_cust_cd        = param_item_cust_cd AND item_cd            = param_item_cd AND item_rev_no = param_item_rev_no
			 AND    finished_flg        = 0 AND expand_div > 0
		 );
		 
		 /*SET prev_plan_shipment_qtty = (
			 SELECT SUM(s_order_remain_s_order_unit) FROM ro_data
			 WHERE  delivery_date      >= (SELECT this_month_start_date FROM m_sys_admin)   AND delivery_date < param_date_from
			 AND    item_cust_cd        = param_item_cust_cd AND item_cd       = param_item_cd AND item_rev_no = param_item_rev_no
			 AND    finished_flg = 0
		 );*/
	 ELSE 
	 	SET prev_plan_prod_qtty     = (
		     SELECT SUM(request_remain_struct_unit) FROM pl_sched_detail 
			  WHERE plan_prod_date  >= (SELECT this_month_start_date FROM m_sys_admin)   AND plan_prod_date < param_date_from
			  AND   item_cust_cd     = param_item_cust_cd AND item_cd        = param_item_cd AND item_rev_no = param_item_rev_no 
			  AND   finished_flg     = 0 AND outside_flg = 1 AND request_remain_struct_unit > 0 AND item_rev_no NOT LIKE '%_MOVE%'
			  AND   expand_div = 0
		 );
		 
		 SET prev_plan_use_qtty      = (	 
			 SELECT SUM(request_remain_struct_unit)  FROM pl_sched_detail 
			 WHERE  plan_delivery_date >= (SELECT this_month_start_date FROM m_sys_admin)   AND plan_delivery_date < param_date_from
			 AND    item_cust_cd        = param_item_cust_cd AND item_cd            = param_item_cd AND item_rev_no = param_item_rev_no
			 AND    finished_flg        = 0 AND expand_div > 0 AND finished_flg = 0 AND request_remain_struct_unit > 0
		 );
	 END IF;
	 /*
	 SET next_plan_prod_qtty     = (
	     SELECT SUM(request_remain_struct_unit) FROM pl_sched_detail 
		  WHERE plan_prod_date   > param_date_from   AND plan_prod_date <= next_7_date
		  AND   item_cust_cd     = param_item_cust_cd AND item_cd        = param_item_cd AND item_rev_no = param_item_rev_no 
		  AND   finished_flg     = 0 AND expand_div = 0
	 );
	 
	 SET next_plan_use_qtty      = (	 
		 SELECT SUM(request_remain_struct_unit)  FROM pl_sched_detail 
		 WHERE  plan_delivery_date > param_date_from     AND plan_delivery_date <= next_7_date
		 AND    item_cust_cd        = param_item_cust_cd AND item_cd            = param_item_cd AND item_rev_no = param_item_rev_no
		 AND    finished_flg        = 0 AND expand_div > 0
	 );
	 
	 SET next_plan_shipment_qtty = (
		 SELECT SUM(s_order_remain_s_order_unit) FROM ro_data
		 WHERE  delivery_date      > param_date_from   AND delivery_date <= next_7_date
		 AND    item_cust_cd        = param_item_cust_cd AND item_cd       = param_item_cd AND item_rev_no = param_item_rev_no
		 AND    finished_flg = 0
	 );*/
    SET good_stock_qtty = IFNULL(first_stock_qtty,0) + IFNULL(stock_in_qtty,0) - IFNULL(stock_out_qtty,0) - IFNULL(scrap_qtty,0);
    SET prev_stock_qtty = IFNULL(first_stock_qtty,0) + IFNULL(stock_in_qtty,0) - IFNULL(stock_out_qtty,0) - IFNULL(scrap_qtty,0) + IFNULL(prev_plan_prod_qtty,0) - IFNULL(prev_plan_use_qtty,0) - IFNULL(prev_plan_shipment_qtty,0);
    /*
    IF param_stock_type = 'FIRST_GOOD_STOCK_QTTY' THEN SET stock_qtty = first_stock_qtty; END IF;
    IF param_stock_type = 'GOOD_STOCK_IN_QTTY'    THEN SET stock_qtty = stock_in_qtty;    END IF;
    IF param_stock_type = 'GOOD_STOCK_OUT_QTTY'   THEN SET stock_qtty = stock_out_qtty;   END IF;
    IF param_stock_type = 'SCRAP_STOCK_QTTY'      THEN SET stock_qtty = scrap_qtty;       END IF;
    IF param_stock_type = 'GOOD_STOCK_QTTY'       THEN SET stock_qtty = IFNULL(first_stock_qtty,0) + IFNULL(stock_in_qtty,0) - IFNULL(stock_out_qtty,0) - IFNULL(scrap_qtty,0);  END IF;
    IF param_stock_type = 'PLAN_GOOD_STOCK_QTTY'  THEN SET stock_qtty = IFNULL(first_stock_qtty,0) + IFNULL(stock_in_qtty,0) - IFNULL(stock_out_qtty,0) - IFNULL(scrap_qtty,0) + IFNULL(prev_plan_prod_qtty,0) - IFNULL(prev_plan_use_qtty,0) - IFNULL(prev_plan_shipment_qtty,0);  END IF;
    IF param_stock_type = 'PLAN_PROD_QTTY'        THEN SET stock_qtty = IFNULL(prev_plan_prod_qtty,0);     END IF;
    IF param_stock_type = 'PLAN_USE_QTTY'         THEN SET stock_qtty = IFNULL(prev_plan_use_qtty,0);      END IF;
    IF param_stock_type = 'PLAN_SHIPMENT_QTTY'    THEN SET stock_qtty = IFNULL(prev_plan_shipment_qtty,0); END IF;*/
    /*
    IF param_stock_type = 'NEXT_PROD_QTTY'        THEN SET stock_qtty = IFNULL(next_plan_prod_qtty,0);     END IF;
    IF param_stock_type = 'NEXT_USE_QTTY'         THEN SET stock_qtty = IFNULL(next_plan_use_qtty,0);     END IF;
    IF param_stock_type = 'NEXT_SHIPMENT_QTTY'    THEN SET stock_qtty = IFNULL(next_plan_shipment_qtty,0);     END IF;*/
    
#    SELECT first_stock_qtty, stock_in_qtty, stock_out_qtty, scrap_qtty;
    /*RETURN JSON_OBJECT('first_stock_qtty', IFNULL(first_stock_qtty,0.00), 'good_stock_in_qtty', IFNULL(stock_in_qtty,0.00), 'good_stock_out_qtty', IFNULL(stock_out_qtty,0.00), 'scrap_qtty', IFNULL(scrap_qtty,0.00), 'good_stock_qtty', IFNULL(good_stock_qtty,0.00), 'prev_stock_qtty', IFNULL(prev_stock_qtty,0.00),
	                    'prev_plan_prod_qtty', IFNULL(prev_plan_prod_qtty,0.00), 'prev_plan_use_qtty', IFNULL(prev_plan_use_qtty,0.00), 'prev_plan_shipment_qtty', IFNULL(prev_plan_shipment_qtty,0.00));*/
	RETURN CONCAT('{', '"', 'first_stock_qtty', '"', ':', IFNULL(first_stock_qtty,0.00), ',', 
                   '"', 'good_stock_in_qtty', '"', ':', IFNULL(stock_in_qtty,0.00), ',',
                   '"', 'good_stock_out_qtty', '"', ':', IFNULL(stock_out_qtty,0.00), ',',
                   '"', 'scrap_qtty', '"', ':', IFNULL(scrap_qtty,0.00), ',',                   
                   '"', 'good_stock_qtty', '"', ':', IFNULL(good_stock_qtty,0.00), ',',  
                   '"', 'prev_stock_qtty', '"', ':', IFNULL(prev_stock_qtty,0.00), ',',
						 '"', 'prev_plan_prod_qtty', '"', ':',IFNULL(prev_plan_prod_qtty,0.00), ',',                                      						                          
						 '"', 'prev_plan_use_qtty', '"', ':', IFNULL(prev_plan_use_qtty,0.00), ',', 
						 '"', 'prev_plan_shipment_qtty', '"', ':', IFNULL(prev_plan_shipment_qtty,0.00), '}');
END;

